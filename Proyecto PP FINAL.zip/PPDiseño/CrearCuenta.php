<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<title>ET 32</title>
	
     <!-- Normalize CSS -->
	<link rel="stylesheet" href="css/normalize.css">
    
     <!-- Materialize CSS -->
	<link rel="stylesheet" href="css/materialize.min.css">
    
     <!-- Material Design Iconic Font CSS -->
	<link rel="stylesheet" href="css/material-design-iconic-font.min.css">
    
    <!-- Malihu jQuery custom content scroller CSS -->
	<link rel="stylesheet" href="css/jquery.mCustomScrollbar.css">
    
    <!-- Sweet Alert CSS -->
    <link rel="stylesheet" href="css/sweetalert.css">
    
    <!-- MaterialDark CSS -->
	<link rel="stylesheet" href="css/style.css">
</head>
<body class="font-cover" id="login">
    <div class="container-login center-align" style="background-color: rgba(0,0,0,0.5);opacity: 1;">
        <div style="margin:15px 0;">
            <i class="zmdi zmdi-account-circle zmdi-hc-5x" style="color: white;"></i>
            <p style="color: white;">Crear Cuenta</p>   
        </div>
        <form method=post>
            <div class="row">
                    <div class="input-field col s6">
                            <input name="nombre"id="Name" type="text" class="validate" style="color: white;" required="required">
                            <label for="Name"><i class="zmdi zmdi-account"></i>&nbsp; Nombre</label>
                        </div>
                        <div class="input-field col s6">
                            <input id="LastName" name="apellido" type="text" class="validate" style="color: white;" required="required">
                            <label for="LastName"><i class="zmdi zmdi-account"></i>&nbsp; Apellido</label>
                        </div>
                        <div class="input-field col s6">
                            <input id="LastName" name="dni" type="text" class="validate" style="color: white;" required="required">
                            <label for="LastName"><i class="zmdi zmdi-account"></i>&nbsp; DNI</label>
                        </div>
                        <div class="input-field col s6">
                            <input id="LastName" name="direccion" type="text" class="validate" style="color: white;" required="required">
                            <label for="LastName"><i class="zmdi zmdi-account"></i>&nbsp; Dirección</label>
                        </div>
                        <div class="input-field col s6">
                            <input id="LastName" name="telefono" type="text" class="validate" style="color: white;" required="required">
                            <label for="LastName"><i class="zmdi zmdi-account"></i>&nbsp; Telefono</label>
                        </div>
                        <div class="input-field col s6">
                            <input id="LastName" name="rol" type="text" class="validate" style="color: white;" required="required">
                            <label for="LastName"><i class="zmdi zmdi-account"></i>&nbsp; Rol</label>
                        </div>
                        <div class="input-field col s6">
                            <input id="LastName" name="legajo" type="text" class="validate" style="color: white;" required="required">
                            <label for="LastName"><i class="zmdi zmdi-account"></i>&nbsp; Legajo</label>
                        </div>
                        <div class="input-field col s6">
                                <input id="Password" name="contraseña" type="password" class="validate" style="color: white;" required="required">
                                <label for="Password"><i class="zmdi zmdi-lock"></i>&nbsp; Contraseña</label>
                            </div>
                        <div class="input-field col s6">
                            <input id="RepPassword" name="repContraseña"type="password" class="validate" style="color: white;" required="required">
                            <label for="RepPassword"><i class="zmdi zmdi-lock"></i>&nbsp; Rep. Contra</label>
                        </div>
            </div>
            <div class="input-field ">
                <input id="Email" name="email" type="email" class="validate" style="color: white;" required="required">
                <label for="Email"><i class="zmdi zmdi-email"></i>&nbsp; Email</label>
            </div>
            <button class="waves-effect waves-teal btn-flat">Enviar &nbsp; <i class="zmdi zmdi-mail-send"></i></button>
        </form>
        <div class="divider" style="margin: 20px 0;"></div>
        <a href="index.html">Iniciar Sesion</a> /
        <a href="#">Olvide la Contraseña</a>
    </div>
    
    <!-- Sweet Alert JS -->
    <script src="js/sweetalert.min.js"></script>
    
    <!-- jQuery -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
	<script>window.jQuery || document.write('<script src="js/jquery-2.2.0.min.js"><\/script>')</script>
    <script src="js/functions.js"></script>
    <!-- Materialize JS -->
	<script src="js/materialize.min.js"></script>
    
    <!-- Malihu jQuery custom content scroller JS -->
	<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
    
    <!-- MaterialDark JS -->
	<script src="js/main.js"></script>
</body>
</html>