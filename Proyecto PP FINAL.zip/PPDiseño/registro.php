<?php

	$nombre=$_POST['nombre'];
	$apellido=$_POST['apellido'];
	$dni=$_POST['dni'];
	$direccion=$_POST['direccion'];
	$telefono=$_POST['telefono'];
	$rol=$_POST['rol'];
	$contraseña= $_POST['contraseña'];
	$repetir=$_POST['repContraseña'];
	$mail=$_POST['email'];
	$leg=$_POST['legajo'];
	
	require("connection.php");
	$checkemail=mysql_query("SELECT * FROM usuarios WHERE correo='$mail'");
	$check_mail=mysql_num_rows($checkemail);
		if($contraseña==$repetir){
			if($check_mail>0){
				echo ' <script language="javascript">alert("Atencion, ya existe el mail designado para un usuario, verifique sus datos");</script> ';
			}else{
				
				//require("connect_db.php");
				mysql_query("INSERT INTO usuarios VALUES('','$nombre','$apellido','$dni','$mail','$direccion','$telefono','$leg','$contraseña','$rol')");
				//echo 'Se ha registrado con exito';
				echo ' <script language="javascript">alert("Usuario registrado con éxito");</script> ';
				mysql_close($link);
				header("Location: localhost/PPdiseño/home.html");
			}
			
		}else{
			echo 'Las contraseñas son incorrectas';
		}

	
?>