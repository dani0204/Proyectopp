<?php $this->load->view('menus/Head');?>
<body class="font-cover" id="login">
    <div class="container-login center-align" style="background-color: rgba(0,0,0,0.5);opacity: 1;">
        <div style="margin:15px 0;">
            <i class="zmdi zmdi-account-circle zmdi-hc-5x" style="color: white;"></i>
            <p style="color: white;">Crear Cuenta</p>   
        </div>
        <form action="index.html">
            <div class="row">
                    <div class="input-field col s6">
                            <input id="Name" type="text" class="validate" style="color: white;" required="required">
                            <label for="Name"><i class="zmdi zmdi-account"></i>&nbsp; Nombre</label>
                        </div>
                        <div class="input-field col s6">
                            <input id="LastName" type="text" class="validate" style="color: white;" required="required">
                            <label for="LastName"><i class="zmdi zmdi-account"></i>&nbsp; Apellido</label>
                        </div>
                        <div class="input-field col s12">
                                <input id="UserName" type="text" class="validate" style="color: white;" required="required">
                                <label for="UserName"><i class="zmdi zmdi-account"></i>&nbsp; Usuario</label>
                            </div>
                        <div class="input-field col s6">
                                <input id="Password" type="password" class="validate" style="color: white;" required="required">
                                <label for="Password"><i class="zmdi zmdi-lock"></i>&nbsp; Contraseña</label>
                            </div>
                        <div class="input-field col s6">
                            <input id="RepPassword" type="password" class="validate" style="color: white;" required="required">
                            <label for="RepPassword"><i class="zmdi zmdi-lock"></i>&nbsp; Rep. Contra</label>
                        </div>
            </div>
            <div class="input-field ">
                <input id="Email" type="email" class="validate" style="color: white;" required="required">
                <label for="Email"><i class="zmdi zmdi-email"></i>&nbsp; Email</label>
            </div>
            <button class="waves-effect waves-teal btn-flat">Enviar &nbsp; <i class="zmdi zmdi-mail-send"></i></button>
        </form>
        <div class="divider" style="margin: 20px 0;"></div>
        <a href="<?= base_url('Login')?>">Iniciar Sesion</a> /
        <a href="#">Olvide la Contraseña</a>
    </div>
    <?php $this->load->view('menus/Script');?>