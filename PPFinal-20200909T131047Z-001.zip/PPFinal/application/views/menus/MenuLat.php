<?php $this->load->view('menus/Head');?>
<body>
    <!-- Nav Lateral -->
    <section class="NavLateral full-width" style="position: fixed;">
      <div class="NavLateral-FontMenu full-width ShowHideMenu"></div>
      <div class="NavLateral-content full-width">
        <header class="NavLateral-title full-width center-align">
          E.T N°32 DE 14<i
            class="zmdi zmdi-close NavLateral-title-btn ShowHideMenu"
          ></i>
        </header>
        <figure class="full-width NavLateral-logo">
          <img
            src="assets/img/logo.gif"
            alt="material-logo"
            class="responsive-img center-box"
          />
          <figcaption class="center-align">
            Escuela Técnica Gral. J. de San Martín
          </figcaption>
        </figure>
        <div class="NavLateral-Nav">
          <ul class="full-width">
            <li>
              <a href="<?= base_url('Home')?>" class="waves-effect waves-light"
                ><i class="zmdi zmdi-desktop-mac zmdi-hc-fw"></i> perfil</a
              >
            </li>
            <li class="NavLateralDivider"></li>
            <li>
              <a href="<?= base_url('AlumnG')?>" class="waves-effect waves-light"
                ><i class="zmdi zmdi-account zmdi-hc-fw"></i> Alumnos</a
              >
            </li>
            <li class="NavLateralDivider"></li>
            <li>
              <a href="#" class="NavLateral-DropDown  waves-effect waves-light"
                ><i class="zmdi zmdi-view-web zmdi-hc-fw"></i>
                <i class="zmdi zmdi-chevron-down NavLateral-CaretDown"></i>
                Becas</a
              >
              <ul class="full-width">
                <li>
                  <a href="<?= base_url('BecAgrAlumn')?>" class="waves-effect waves-light"
                    ><i
                      class="zmdi zmdi-lock NavLateral-CaretDown NavLateral-CaretDown "
                    ></i
                    >&nbsp;Agregar Alumnos</a
                  >
                </li>
                <li class="NavLateralDivider"></li>
                <li>
                  <a href="<?= base_url('BecDatosAlum')?>" class="waves-effect waves-light"
                    ><i
                      class="zmdi zmdi-lock NavLateral-CaretDown NavLateral-CaretDown "
                    ></i
                    >&nbsp;Aprobacion de Becas
                    </a
                  >
                </li>
              </ul>
            </li>
            <li class="NavLateralDivider"></li>
            <li>
              <a href="#" class="NavLateral-DropDown  waves-effect waves-light"
                ><i class="zmdi zmdi-assignment zmdi-hc-fw"></i>
                <i class="zmdi zmdi-chevron-down NavLateral-CaretDown"></i>
                Inscripciones</a
              >
              <ul class="full-width">
                <li>
                  <a href="<?= base_url('InscAlumn')?>" class="waves-effect waves-light"
                    ><i
                      class="zmdi zmdi-lock NavLateral-CaretDown NavLateral-CaretDown "
                    ></i
                    >&nbsp;Inscribir Alumnos</a
                  >
                </li>
                <li class="NavLateralDivider"></li>
                <li>
                  <a href="<?= base_url('InscUsuario')?>" class="waves-effect waves-light"
                    ><i
                      class="zmdi zmdi-lock NavLateral-CaretDown NavLateral-CaretDown "
                    ></i
                    >&nbsp;Usuarios</a
                  >
                </li>
              </ul>
            </li>
            <li class="NavLateralDivider"></li>
            <li>
              <a href="#" class="NavLateral-DropDown  waves-effect waves-light"
                ><i class="zmdi zmdi-widgets zmdi-hc-fw"></i>
                <i class="zmdi zmdi-chevron-down NavLateral-CaretDown"></i>
                Previas</a
              >
              <ul class="full-width">
                <li>
                  <a href="<?= base_url('PrevAlumn')?>" class="waves-effect waves-light"
                    ><i
                      class="zmdi zmdi-lock NavLateral-CaretDown NavLateral-CaretDown "
                    ></i
                    >&nbsp;Agregar Alumnos</a
                  >
                </li>
                <li class="NavLateralDivider"></li>
                <li>
                  <a href="<?= base_url('DefMatPrev')?>" class="waves-effect waves-light"
                    ><i
                      class="zmdi zmdi-lock NavLateral-CaretDown NavLateral-CaretDown "
                    ></i
                    >&nbsp;Definir materias Previas</a
                  >
                </li>
              </ul>
            </li>
            <li class="NavLateralDivider"></li>
            <li>
              <a href="#" class="NavLateral-DropDown  waves-effect waves-light"
                ><i class="zmdi zmdi-widgets zmdi-hc-fw"></i>
                <i class="zmdi zmdi-chevron-down NavLateral-CaretDown"></i>
                Registro Materias por Alumnos</a
              >
              <ul class="full-width">
                <li>
                  <a href="<?= base_url('CicloBasico')?>" class="waves-effect waves-light"
                    ><i
                      class="zmdi zmdi-lock NavLateral-CaretDown NavLateral-CaretDown "
                    ></i
                    >&nbsp;Ciclo Basico</a
                  >
                </li>
                <li class="NavLateralDivider"></li>
                <li>
                  <a href="<?= base_url('CicloSuperior')?>" class="waves-effect waves-light"
                    ><i
                      class="zmdi zmdi-lock NavLateral-CaretDown NavLateral-CaretDown "
                    ></i
                    >&nbsp;Ciclo Superior</a
                  >
                </li>
              </ul>
            </li>
            <li class="NavLateralDivider"></li>
          </ul>
        </div>
      </div>
    </section>