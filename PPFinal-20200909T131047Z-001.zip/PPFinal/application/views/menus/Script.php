
<!-- Sweet Alert JS -->
<script src="js/sweetalert.min.js"></script>
    <!-- jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
    <script>
      window.jQuery ||
        document.write('<script src="js/jquery-2.2.0.min.js"><\/script>');
    </script>
    <script src="js/functions.js"></script>
    <script>
      document.addEventListener("DOMContentLoaded", function() {
        var elems = document.querySelectorAll(".modal");
        var instances = M.Modal.init(elems, options);
      });
      // Or with jQuery
      $(document).ready(function() {
        $(".modal").modal();
      });
    </script>
    <script type="text/javascript">
      $(document).ready(function() {
        $("#example").DataTable();
      });
    </script>
    <script>
      document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.datepicker');
    var instances = M.Datepicker.init(elems, options);
  });

  // Or with jQuery

  $(document).ready(function(){
    $('.datepicker').datepicker();
  });</script>
  <script>
      document.addEventListener("DOMContentLoaded", function() {
        var elems = document.querySelectorAll(".collapsible");
        var instances = M.Collapsible.init(elems, options);
      });

      // Or with jQuery

      $(document).ready(function() {
        $(".collapsible").collapsible();
      });
    </script>
    <script>
    jQuery(".btn-ahora").click(function() {
        swal({
            title: "¿Seguro que deseas Eliminar?",   
            text: "No podras deshacer este paso...",   
            type: "error",   
            showCancelButton: true,
            cancelButtonText: "DENEGAR",   
            confirmButtonColor: "#DD6B55",   
            confirmButtonText: "CONTINUAR",   
            closeOnConfirm: false });
    });
    </script>
    <!-- Materialize JS -->
    <script src="js/materialize.min.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>
    <script src="js/dataTables.responsive.min.js" charset="utf-8"></script>
    <!-- Malihu jQuery custom content scroller JS -->
    <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>

    <!-- MaterialDark JS -->
    <script src="js/main.js"></script>
  </body>
</html>
