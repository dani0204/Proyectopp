<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>ET 32</title>

    <!-- Normalize CSS -->
    <link rel="stylesheet" href="css/normalize.css" />
    <link rel="stylesheet" href="css/mstepper.min.css">
    <link rel="stylesheet" href="css/materialize-stepper.css">
    <!-- Materialize CSS -->
    <link rel="stylesheet" href="css/materialize.min.css" />

    <!-- Material Design Iconic Font CSS -->
    <link rel="stylesheet" href="css/material-design-iconic-font.min.css" />

    <!-- Malihu jQuery custom content scroller CSS -->
    <link rel="stylesheet" href="css/jquery.mCustomScrollbar.css" />

    <!-- Sweet Alert CSS -->
    <link rel="stylesheet" href="css/sweetalert.css" />

    <!-- MaterialDark CSS -->
    <link rel="stylesheet" href="css/style.css" />
    <!--otros-->
    <link rel="stylesheet" href="css/jquery.dataTables.min.css" />
    <link rel="stylesheet" href="css/responsive.dataTables.min.css" />

    <link rel="shortcut icon" href="assets/img/logo.gif"/>

  </head>