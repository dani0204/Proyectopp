<?php $this->load->view('menus/MenuLat');?>
<!-- Page content -->
<section class="ContentPage full-width">
      <!-- Nav Info -->
      <div class="ContentPage-Nav full-width">
        <ul class="full-width">
          <li class="btn-MobileMenu ShowHideMenu">
            <a
              href="#"
              class="tooltipped waves-effect waves-light"
              data-position="bottom"
              data-delay="50"
              data-tooltip="Menu"
              ><i class="zmdi zmdi-more-vert"></i
            ></a>
          </li>
          <li>
            <figure><img src="assets/img/user.png" alt="UserImage" /></figure>
          </li>
          <li style="padding:0 5px;">User Name</li>
          <li>
            <a
              href="#"
              class="tooltipped waves-effect waves-light btn-ExitSystem"
              data-position="bottom"
              data-delay="50"
              data-tooltip="Salir"
              ><i class="zmdi zmdi-power"></i
            ></a>
          </li>
          <li>
            <a
              href="#"
              class="tooltipped waves-effect waves-light btn-Search"
              data-position="bottom"
              data-delay="50"
              data-tooltip="Buscar"
              ><i class="zmdi zmdi-search"></i
            ></a>
          </li>
        </ul>
      </div>