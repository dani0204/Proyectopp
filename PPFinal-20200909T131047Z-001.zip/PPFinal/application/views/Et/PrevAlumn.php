<!--Agregar Alumnos a Becas-->
<?php $this->load->view('menus/NavLat');?>

<div class="row">
  <!-- Tiles -->

  <!--HighlightTable-->
  <div class="container">
    <div class="row">
      <h2 class="center-align">Inscripciones a Previas</h2>
      <div class="col s12">
        <!-- Modal Trigger -->
        <a
          class="waves-effect waves-light btn modal-trigger"
          href="#modal1"
          style="
    background-color: #006699;
"
          ><i class="zmdi zmdi-account-add zmdi-hc-fw"></i>&nbsp;Agregar
          Alumnos</a
        >
        <!-- Modal Structure -->
        <div
          id="modal1"
          class="modal modal-fixed mCustomScrollbar"
          data-mcs-theme="dark"
        >
          <div class="modal-content">
            <div class="container">
              <div class="row">
                <h2 class="center-align">Inscribir Alumnos a Previas</h2>
                <form class="col s12" action="#">
                  <div class="row">
                    <div class="input-field col s6">
                      <i class="zmdi zmdi-account-circle prefix"></i>
                      <input
                        id="Name"
                        type="text"
                        class="validate"
                        required="required"
                      />
                      <label for="Name">Nombre</label>
                    </div>
                    <div class="input-field col s6">
                      <i class="zmdi zmdi-account-circle prefix"></i>
                      <input
                        id="Apellido"
                        type="text"
                        class="validate"
                        required="required"
                      />
                      <label for="Apellico">Apellido</label>
                    </div>
                    <div class="input-field col s6">
                      <i class="zmdi zmdi-folder-shared prefix"></i>
                      <input
                        id="DNI"
                        type="tel"
                        class="validate"
                        required="required"
                      />
                      <label for="DNI">DNI</label>
                    </div>
                  </div>
                  <h2 class="center-align">Materias a cursar</h2>
                  <div class="input-field col s6">
                    <select>
                      <option value="" disabled selected>Previa 1</option>
                      <option value="1">Ninguna</option>
                      <option value="2">Computacion</option>
                      <option value="3">Mecanica</option>
                      <option value="4">Automotores</option>
                    </select>
                  </div>
                  <div class="input-field col s6">
                    <select>
                      <option value="" disabled selected>Previa 2</option>
                      <option value="1">Ninguna</option>
                      <option value="2">Computacion</option>
                      <option value="3">Mecanica</option>
                      <option value="4">Automotores</option>
                    </select>
                  </div>
                  <div class="input-field col s6">
                    <i class="zmdi zmdi-assignment prefix"></i>
                    <input id="otras" type="tel" required="required" />
                    <label for="otras">Otras</label>
                  </div>
                  <button
                    class="waves-effect waves-teal btn-flat col s12"
                    style="background-color: #006699;margin-bottom: 5%;"
                  >
                    Enviar Nuevo Alumno <i class="zmdi zmdi-mail-send"></i>
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--kkkkkkkkkkkk-->
  <div class="container" style="margin-bottom: 128px;">
    <div class="row">
      <table
        id="example"
        class="display responsive nowrap"
        cellspacing="0"
        width="100%"
      >
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>DNI</th>
            <th>Previa 1</th>
            <th>Previa 2</th>
            <th>Otras</th>
            <th>Accion</th>
          </tr>
        </thead>

        <tbody>
          <tr>
            <td>Tiger</td>
            <td>Nixon</td>
            <td>12.345.657</td>
            <td>materia 1</td>
            <td>materia 2</td>
            <td>---</td>
            <td>
              <a
                class="btn green darken-2 waves-effect waves-light modal-trigger"
                href="#modal2"
              >
                <i class="zmdi zmdi-edit"></i>
              </a>
            </td>
          </tr>
          <tr>
            <td>Garrett</td>
            <td>Winters</td>
            <td>12.345.657</td>
            <td>materia 1</td>
            <td>materia 2</td>
            <td>---</td>
            <td>
              <button
                class="btn green darken-2 waves-effect waves-light compact-btn"
              >
                <i class="zmdi zmdi-edit"></i>
              </button>
            </td>
          </tr>
          <tr>
            <td>Ashton</td>
            <td>Cox</td>
            <td>12.345.657</td>
            <td>materia 1</td>
            <td>materia 2</td>
            <td>---</td>
            <td>
              <button
                class="btn green darken-2 waves-effect waves-light compact-btn"
              >
                <i class="zmdi zmdi-edit"></i>
              </button>
            </td>
          </tr>
          <tr>
            <td>Cedric</td>
            <td>Kelly</td>
            <td>12.345.657</td>
            <td>materia 1</td>
            <td>materia 2</td>
            <td>---</td>
            <td>
              <button
                class="btn green darken-2 waves-effect waves-light compact-btn"
              >
                <i class="zmdi zmdi-edit"></i>
              </button>
            </td>
          </tr>
          <tr>
            <td>Airi</td>
            <td>Satou</td>
            <td>12.345.657</td>
            <td>materia 1</td>
            <td>materia 2</td>
            <td>---</td>
            <td>
              <button
                class="btn green darken-2 waves-effect waves-light compact-btn"
              >
                <i class="zmdi zmdi-edit"></i>
              </button>
            </td>
          </tr>
          <tr>
            <td>Brielle</td>
            <td>Williamson</td>
            <td>12.345.657</td>
            <td>materia 1</td>
            <td>materia 2</td>
            <td>---</td>
            <td>
              <button
                class="btn green darken-2 waves-effect waves-light compact-btn"
              >
                <i class="zmdi zmdi-edit"></i>
              </button>
            </td>
          </tr>
          <tr>
            <td>Herrod</td>
            <td>Chandler</td>
            <td>12.345.657</td>
            <td>materia 1</td>
            <td>materia 2</td>
            <td>---</td>
            <td>
              <button
                class="btn green darken-2 waves-effect waves-light compact-btn"
              >
                <i class="zmdi zmdi-edit"></i>
              </button>
            </td>
          </tr>
          <tr>
            <td>Rhona</td>
            <td>Davidson</td>
            <td>12.345.657</td>
            <td>materia 1</td>
            <td>materia 2</td>
            <td>---</td>
            <td>
              <button
                class="btn green darken-2 waves-effect waves-light compact-btn"
              >
                <i class="zmdi zmdi-edit"></i>
              </button>
            </td>
          </tr>
          <tr>
            <td>Colleen</td>
            <td>Hurst</td>
            <td>12.345.657</td>
            <td>materia 1</td>
            <td>materia 2</td>
            <td>---</td>
            <td>
              <button
                class="btn green darken-2 waves-effect waves-light compact-btn"
              >
                <i class="zmdi zmdi-edit"></i>
              </button>
            </td>
          </tr>
          <tr>
            <td>Sonya</td>
            <td>Frost</td>
            <td>12.345.657</td>
            <td>materia 1</td>
            <td>materia 2</td>
            <td>---</td>
            <td>
              <button
                class="btn green darken-2 waves-effect waves-light compact-btn"
              >
                <i class="zmdi zmdi-edit"></i>
              </button>
            </td>
          </tr>
          <tr>
            <td>Jena</td>
            <td>Gaines</td>
            <td>12.345.657</td>
            <td>materia 1</td>
            <td>materia 2</td>
            <td>---</td>
            <td>
              <button
                class="btn green darken-2 waves-effect waves-light compact-btn"
              >
                <i class="zmdi zmdi-edit"></i>
              </button>
            </td>
          </tr>
        </tbody>
      </table>
      <!-- Modal Structure -->
      <div
        id="modal2"
        class="modal modal-fixed mCustomScrollbar"
        data-mcs-theme="dark"
      >
        <div class="modal-content">
          <div class="container">
            <div class="row">
              <h2 class="center-align">Inscribir Alumnos a Previas</h2>
              <form class="col s12" action="#">
                <div class="row">
                  <div class="input-field col s6">
                    <i class="zmdi zmdi-account-circle prefix"></i>
                    <input
                      id="Name"
                      type="text"
                      class="validate"
                      required="required"
                    />
                    <label for="Name">Nombre</label>
                  </div>
                  <div class="input-field col s6">
                    <i class="zmdi zmdi-account-circle prefix"></i>
                    <input
                      id="Apellido"
                      type="text"
                      class="validate"
                      required="required"
                    />
                    <label for="Apellico">Apellido</label>
                  </div>
                  <div class="input-field col s6">
                    <i class="zmdi zmdi-folder-shared prefix"></i>
                    <input
                      id="DNI"
                      type="tel"
                      class="validate"
                      required="required"
                    />
                    <label for="DNI">DNI</label>
                  </div>
                </div>
                <h2 class="center-align">Materias a cursar</h2>
                <div class="input-field col s6">
                  <select>
                    <option value="" disabled selected>Previa 1</option>
                    <option value="1">Ninguna</option>
                    <option value="2">Computacion</option>
                    <option value="3">Mecanica</option>
                    <option value="4">Automotores</option>
                  </select>
                </div>
                <div class="input-field col s6">
                  <select>
                    <option value="" disabled selected>Previa 2</option>
                    <option value="1">Ninguna</option>
                    <option value="2">Computacion</option>
                    <option value="3">Mecanica</option>
                    <option value="4">Automotores</option>
                  </select>
                </div>
                <div class="input-field col s6">
                  <i class="zmdi zmdi-assignment prefix"></i>
                  <input id="otras" type="tel" required="required" />
                  <label for="otras">Otras</label>
                </div>
                <button
                  class="waves-effect waves-teal btn-flat col s12"
                  style="background-color: #006699;margin-bottom: 5%;"
                >
                  Enviar Nuevo Alumno <i class="zmdi zmdi-mail-send"></i>
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $this->load->view('menus/Footer');?>