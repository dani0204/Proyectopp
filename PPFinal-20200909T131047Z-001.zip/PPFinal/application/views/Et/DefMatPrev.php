<!--Definir Materias Previas-->
<?php $this->load->view('menus/NavLat');?>

<div class="row">
  <!-- Tiles -->
  <!--HighlightTable-->
  <div class="container">
    <div class="row">
      <h2 class="center-align">Definir Materia Previas</h2>
      <div class="col s12">
        <!-- Modal Trigger -->
        <a
          class="waves-effect waves-light btn modal-trigger"
          href="#modal1"
          style="
                  background-color: #006699;
                  "
          ><i class="zmdi zmdi-file-text zmdi-hc-fw"></i>&nbsp;Agregar
          Materias</a
        >
        <!-- Modal Structure -->
        <div
          id="modal1"
          class="modal modal-fixed mCustomScrollbar"
          data-mcs-theme="dark"
        >
          <div class="modal-content">
            <div class="container">
              <div class="row">
                <h2 class="center-align">Materias Previas</h2>
                <form class="col s12" action="#">
                  <div class="row">
                    <div class="input-field col s6">
                      <i class="zmdi zmdi-assignment prefix"></i>
                      <input
                        id="NameM"
                        type="text"
                        class="validate"
                        required="required"
                      />
                      <label for="NameM">Nombre de Materia</label>
                    </div>
                    <div class="input-field col s6">
                      <i class="zmdi zmdi-account-circle prefix"></i>
                      <input
                        id="NameP"
                        type="text"
                        class="validate"
                        required="required"
                      />
                      <label for="NameP">Nombre de Prof.</label>
                    </div>
                    <div class="input-field col s6">
                      <i class="zmdi zmdi-folder-shared prefix"></i>
                      <input
                        id="Años"
                        type="tel"
                        class="validate"
                        required="required"
                      />
                      <label for="Años">Años</label>
                    </div>
                  </div>
                  <div class="input-field col s6">
                    <i class="zmdi zmdi-calendar prefix"></i>
                    <input id="otras" type="tel" required="required" />
                    <label for="otras">Dias</label>
                  </div>
                  <div class="input-field col s6">
                    <i class="zmdi zmdi-hourglass-alt prefix"></i>
                    <input id="otras" type="tel" required="required" />
                    <label for="otras">Horarios </label>
                  </div>
                  <button
                    class="waves-effect waves-teal btn-flat col s12"
                    style="background-color: #006699;margin-bottom: 5%;"
                  >
                    Enviar Nueva Materia
                    <i class="zmdi zmdi-mail-send"></i>
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--kkkkkkkkkkkk-->
  <div class="container" style="margin-bottom: 128px;">
    <div class="row">
      <table
        id="example"
        class="display responsive nowrap"
        cellspacing="0"
        width="100%"
      >
        <thead>
          <tr>
            <th>Materia</th>
            <th>Nombre Prof.</th>
            <th>Años</th>
            <th>Dias</th>
            <th>Horarios</th>
            <th>Accion</th>
          </tr>
        </thead>

        <tbody>
          <tr>
            <td>Tiger</td>
            <td>Nixon</td>
            <td>12.345.657</td>
            <td>materia 1</td>
            <td>materia 2</td>
            <td>
              <a
                class="btn green darken-2 waves-effect waves-light modal-trigger"
                href="#modal2"
              >
                <i class="zmdi zmdi-edit"></i>
              </a>
            </td>
          </tr>
          <tr>
            <td>Garrett</td>
            <td>Winters</td>
            <td>12.345.657</td>
            <td>materia 1</td>
            <td>materia 2</td>
            <td>
              <button
                class="btn green darken-2 waves-effect waves-light compact-btn"
              >
                <i class="zmdi zmdi-edit"></i>
              </button>
            </td>
          </tr>
          <tr>
            <td>Ashton</td>
            <td>Cox</td>
            <td>12.345.657</td>
            <td>materia 1</td>
            <td>materia 2</td>
            <td>
              <button
                class="btn green darken-2 waves-effect waves-light compact-btn"
              >
                <i class="zmdi zmdi-edit"></i>
              </button>
            </td>
          </tr>
          <tr>
            <td>Cedric</td>
            <td>Kelly</td>
            <td>12.345.657</td>
            <td>materia 1</td>
            <td>materia 2</td>
            <td>
              <button
                class="btn green darken-2 waves-effect waves-light compact-btn"
              >
                <i class="zmdi zmdi-edit"></i>
              </button>
            </td>
          </tr>
          <tr>
            <td>Airi</td>
            <td>Satou</td>
            <td>12.345.657</td>
            <td>materia 1</td>
            <td>materia 2</td>
            <td>
              <button
                class="btn green darken-2 waves-effect waves-light compact-btn"
              >
                <i class="zmdi zmdi-edit"></i>
              </button>
            </td>
          </tr>
          <tr>
            <td>Brielle</td>
            <td>Williamson</td>
            <td>12.345.657</td>
            <td>materia 1</td>
            <td>materia 2</td>
            <td>
              <button
                class="btn green darken-2 waves-effect waves-light compact-btn"
              >
                <i class="zmdi zmdi-edit"></i>
              </button>
            </td>
          </tr>
          <tr>
            <td>Herrod</td>
            <td>Chandler</td>
            <td>12.345.657</td>
            <td>materia 1</td>
            <td>materia 2</td>
            <td>
              <button
                class="btn green darken-2 waves-effect waves-light compact-btn"
              >
                <i class="zmdi zmdi-edit"></i>
              </button>
            </td>
          </tr>
          <tr>
            <td>Rhona</td>
            <td>Davidson</td>
            <td>12.345.657</td>
            <td>materia 1</td>
            <td>materia 2</td>
            <td>
              <button
                class="btn green darken-2 waves-effect waves-light compact-btn"
              >
                <i class="zmdi zmdi-edit"></i>
              </button>
            </td>
          </tr>
          <tr>
            <td>Colleen</td>
            <td>Hurst</td>
            <td>12.345.657</td>
            <td>materia 1</td>
            <td>materia 2</td>
            <td>
              <button
                class="btn green darken-2 waves-effect waves-light compact-btn"
              >
                <i class="zmdi zmdi-edit"></i>
              </button>
            </td>
          </tr>
          <tr>
            <td>Sonya</td>
            <td>Frost</td>
            <td>12.345.657</td>
            <td>materia 1</td>
            <td>materia 2</td>
            <td>
              <button
                class="btn green darken-2 waves-effect waves-light compact-btn"
              >
                <i class="zmdi zmdi-edit"></i>
              </button>
            </td>
          </tr>
          <tr>
            <td>Jena</td>
            <td>Gaines</td>
            <td>12.345.657</td>
            <td>materia 1</td>
            <td>materia 2</td>
            <td>
              <button
                class="btn green darken-2 waves-effect waves-light compact-btn"
              >
                <i class="zmdi zmdi-edit"></i>
              </button>
            </td>
          </tr>
        </tbody>
      </table>
      <!-- Modal Structure -->
      <div
        id="modal2"
        class="modal modal-fixed mCustomScrollbar"
        data-mcs-theme="dark"
      >
        <div class="modal-content">
          <div class="container">
            <div class="row">
              <h2 class="center-align">Materias Previas</h2>
              <form class="col s12" action="#">
                <div class="row">
                  <div class="input-field col s6">
                    <i class="zmdi zmdi-assignment prefix"></i>
                    <input
                      id="NameM"
                      type="text"
                      class="validate"
                      required="required"
                    />
                    <label for="NameM">Nombre de Materia</label>
                  </div>
                  <div class="input-field col s6">
                    <i class="zmdi zmdi-account-circle prefix"></i>
                    <input
                      id="NameP"
                      type="text"
                      class="validate"
                      required="required"
                    />
                    <label for="NameP">Nombre de Prof.</label>
                  </div>
                  <div class="input-field col s6">
                    <i class="zmdi zmdi-folder-shared prefix"></i>
                    <input
                      id="Años"
                      type="tel"
                      class="validate"
                      required="required"
                    />
                    <label for="Años">Años</label>
                  </div>
                </div>
                <div class="input-field col s6">
                  <i class="zmdi zmdi-calendar prefix"></i>
                  <input id="otras" type="tel" required="required" />
                  <label for="otras">Dias</label>
                </div>
                <div class="input-field col s6">
                  <i class="zmdi zmdi-hourglass-alt prefix"></i>
                  <input id="otras" type="tel" required="required" />
                  <label for="otras">Horarios </label>
                </div>
                <button
                  class="waves-effect waves-teal btn-flat col s12"
                  style="background-color: #006699;margin-bottom: 5%;"
                >
                  Enviar Nueva Materia <i class="zmdi zmdi-mail-send"></i>
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $this->load->view('menus/Footer');?>