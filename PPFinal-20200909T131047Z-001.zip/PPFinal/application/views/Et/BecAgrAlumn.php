<!--Agregar Alumnos a Becas-->
<?php $this->load->view('menus/NavLat');?>
<!--Input fields-->
<div class="container">
  <div class="row">
    <h2 class="center-align">Agregar Becas de Alumnos</h2>
    <form class="col s12" action="#">
      <div class="row">
        <div class="input-field col s6">
          <i class="zmdi zmdi-account-circle prefix"></i>
          <input id="Name" type="text" class="validate" required="required" />
          <label for="Name">Nombre</label>
        </div>
        <div class="input-field col s6">
          <i class="zmdi zmdi-account-circle prefix"></i>
          <input
            id="Apellido"
            type="text"
            class="validate"
            required="required"
          />
          <label for="Apellico">Apellido</label>
        </div>
        <div class="input-field col s6">
          <i class="zmdi zmdi-folder-shared prefix"></i>
          <input id="DNI" type="tel" class="validate" required="required" />
          <label for="DNI">DNI</label>
        </div>
        <div class="input-field col s6">
          <i class="zmdi zmdi-phone prefix"></i>
          <input
            id="Telefono"
            type="tel"
            class="validate"
            required="required"
          />
          <label for="Telefono">Telefono</label>
        </div>
        <div class="input-field col s3">
          <select>
            <option value="" disabled selected required="required"
              >Año cursado</option
            >
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
          </select>
        </div>
        <div class="input-field col s3">
          <select>
            <option value="" disabled selected>Division</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
          </select>
        </div>
        <div class="input-field col s3">
          <select>
            <option value="" disabled selected>Año cursado</option>
            <option value="1">Mañana</option>
            <option value="2">Tarde</option>
            <option value="3">Noche</option>
          </select>
        </div>

        <div class="input-field col s6">
          <select>
            <option value="" disabled selected>Aprovacion de Beca</option>
            <option value="1">Aprobado</option>
            <option value="2">Rechazado</option>
            <option value="3">Falta</option>
          </select>
        </div>
      </div>
      <button
        class="waves-effect waves-teal btn-flat"
        style="background-color: #006699;"
      >
        Enviar Nuevo Alumno <i class="zmdi zmdi-mail-send"></i>
      </button>
    </form>
  </div>
</div>
<?php $this->load->view('menus/Footer');?>