<!--Datos de Alumnos con Becas-->
<?php $this->load->view('menus/NavLat');?>
<!-- Tables -->
<div class="row">
  <!--HighlightTable-->
  <div class="container" style="margin-bottom: 128px;">
    <div class="row">
      <h2 class="center-align">Aprobacion de Becas</h2>
    </div>
    <table id="example" class="" cellspacing="0" width="100%">
      <thead>
        <tr>
          <th>Nombre</th>
          <th>Apellido</th>
          <th>Año</th>
          <th>Division</th>
          <th>Turno</th>
          <th>DNI</th>
          <th>Aprobacion</th>
        </tr>
      </thead>

      <tbody>
        <tr>
          <td>Tiger</td>
          <td>Nixon</td>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <td class="sorting_1">
            <span class="new badge red" data-badge-caption="">null</span>
          </td>
        </tr>
        <tr>
          <td>Garrett</td>
          <td>Winters</td>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <td class="sorting_1">
            <span class="new badge" data-badge-caption="">Aprobado</span>
          </td>
        </tr>
        <tr>
          <td>Ashton</td>
          <td>Cox</td>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <td class="sorting_1">
            <span class="new badge" data-badge-caption="">Aprobado</span>
          </td>
        </tr>
        <tr>
          <td>Cedric</td>
          <td>Kelly</td>
          <th>1</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <td class="sorting_1">
            <span class="new badge red" data-badge-caption="">null</span>
          </td>
        </tr>
        <tr>
          <td>Airi</td>
          <td>Satou</td>
          <th>2</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <td class="sorting_1">
            <span class="new badge red" data-badge-caption="">null</span>
          </td>
        </tr>
        <tr>
          <td>Brielle</td>
          <td>Williamson</td>
          <th>3</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <td class="sorting_1">
            <span class="new badge orange" data-badge-caption="">Falta</span>
          </td>
        </tr>
        <tr>
          <td>Herrod</td>
          <td>Chandler</td>
          <th>4</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <td class="sorting_1">
            <span class="new badge orange" data-badge-caption="">Falta</span>
          </td>
        </tr>
        <tr>
          <td>Rhona</td>
          <td>Davidson</td>
          <th>5</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <td class="sorting_1">
            <span class="new badge" data-badge-caption="">Aprobado</span>
          </td>
        </tr>
        <tr>
          <td>Colleen</td>
          <td>Hurst</td>
          <th>5</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <td class="sorting_1">
            <span class="new badge" data-badge-caption="">Aprobado</span>
          </td>
        </tr>
        <tr>
          <td>Sonya</td>
          <td>Frost</td>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <td class="sorting_1">
            <span class="new badge red" data-badge-caption="">rechazado</span>
          </td>
        </tr>
        <tr>
          <td>Jena</td>
          <td>Gaines</td>
          <th>6</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <td class="sorting_1">
            <span class="new badge orange" data-badge-caption="">Falta</span>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</div>
<?php $this->load->view('menus/Footer');?>