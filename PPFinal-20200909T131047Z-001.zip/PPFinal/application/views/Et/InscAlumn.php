<!--Inscripcion de Alumnos-->
<?php $this->load->view('menus/NavLat');?>
<!--HighlightTable-->
<div class="container">
  <div class="row">
    <h2 class="center-align">Inscripciones Alumnos</h2>
    <div class="col s12">
      <!-- Modal Trigger -->
      <a
        class="waves-effect waves-light btn modal-trigger"
        href="#modal1"
        style="
    background-color: #006699;
"
        ><i class="zmdi zmdi-account-add zmdi-hc-fw"></i>&nbsp;Agregar
        Alumnos</a
      >
      <!-- Modal Structure -->
      <div
        id="modal1"
        class="modal modal-fixed mCustomScrollbar"
        data-mcs-theme="dark"
      >
        <div class="modal-content">
          <div class=" container">
            <div class="row">
              <h2 class="center-align">Inscribir Alumnos</h2>
              <form class="col s12" action="#">
                <div class="row">
                  <div class="input-field col s6">
                    <i class="zmdi zmdi-account-circle prefix"></i>
                    <input
                      id="Name"
                      type="text"
                      class="validate"
                      required="required"
                    />
                    <label for="Name">Nombre</label>
                  </div>
                  <div class="input-field col s6">
                    <i class="zmdi zmdi-account-circle prefix"></i>
                    <input
                      id="Apellido"
                      type="text"
                      class="validate"
                      required="required"
                    />
                    <label for="Apellico">Apellido</label>
                  </div>
                  <div class="input-field col s6">
                    <i class="zmdi zmdi-pin-drop prefix"></i>
                    <input
                      id="Domicilio"
                      type="text"
                      class="validate"
                      required="required"
                    />
                    <label for="Domicilio">Domicilio</label>
                  </div>
                  <div class="input-field col s6">
                    <i class="zmdi zmdi-email prefix"></i>
                    <input
                      id="Email"
                      type="text"
                      class="validate"
                      required="required"
                    />
                    <label for="Email">Email</label>
                  </div>
                  <div class="input-field col s6">
                    <i class="zmdi zmdi-folder-shared prefix"></i>
                    <input
                      id="DNI"
                      type="tel"
                      class="validate"
                      required="required"
                    />
                    <label for="DNI">DNI</label>
                  </div>
                  <div class="input-field col s6">
                    <i class="zmdi zmdi-phone prefix"></i>
                    <input
                      id="Telefono"
                      type="tel"
                      class="validate"
                      required="required"
                    />
                    <label for="Telefono">Telefono</label>
                  </div>
                  <div class="input-field col s12">
                    <i class="zmdi zmdi-calendar prefix"></i>
                    <input
                      id="Nac"
                      type="tel"
                      class="validate"
                      required="required"
                    />
                    <label for="Nac">Fecha de Nacimiento</label>
                  </div>
                  <div class="input-field col s3">
                    <select>
                      <option value="" disabled selected required="required"
                        >Año</option
                      >
                      <option value="1">1</option>
                      <option value="2">2</option>
                      <option value="3">3</option>
                      <option value="4">4</option>
                      <option value="5">5</option>
                      <option value="6">6</option>
                    </select>
                  </div>
                  <div class="input-field col s3">
                    <select>
                      <option value="" disabled selected>Division</option>
                      <option value="1">1</option>
                      <option value="2">2</option>
                      <option value="3">3</option>
                      <option value="4">4</option>
                      <option value="5">5</option>
                      <option value="6">6</option>
                      <option value="7">7</option>
                      <option value="8">8</option>
                    </select>
                  </div>
                  <div class="input-field col s3">
                    <select>
                      <option value="" disabled selected>Turno</option>
                      <option value="1">Mañana</option>
                      <option value="2">Tarde</option>
                      <option value="3">Noche</option>
                    </select>
                  </div>

                  <div class="input-field col s6">
                    <select>
                      <option value="" disabled selected>Especialidad</option>
                      <option value="1">Ninguna</option>
                      <option value="2">Computacion</option>
                      <option value="3">Mecanica</option>
                      <option value="4">Automotores</option>
                    </select>
                  </div>
                </div>
                <h2 class="center-align">Datos de Tutor</h2>
                <div class="input-field col s6">
                  <i class="zmdi zmdi-account-circle prefix"></i>
                  <input
                    id="Name"
                    type="text"
                    class="validate"
                    required="required"
                  />
                  <label for="Name">Nombre</label>
                </div>
                <div class="input-field col s6">
                  <i class="zmdi zmdi-account-circle prefix"></i>
                  <input
                    id="Apellido"
                    type="text"
                    class="validate"
                    required="required"
                  />
                  <label for="Apellico">Apellido</label>
                </div>
                <div class="input-field col s6">
                  <i class="zmdi zmdi-folder-shared prefix"></i>
                  <input
                    id="DNI"
                    type="tel"
                    class="validate"
                    required="required"
                  />
                  <label for="DNI">DNI</label>
                </div>
                <button
                  class="waves-effect waves-teal btn-flat col s12"
                  style="background-color: #006699;margin-bottom: 5%;"
                >
                  Enviar Nuevo Alumno <i class="zmdi zmdi-mail-send"></i>
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!--kkkkkkkkkkkk-->
<div class="container" style="margin-bottom: 128px;">
  <div class="row">
    <table
      id="example"
      class="display responsive nowrap"
      cellspacing="0"
      width="100%"
    >
      <thead>
        <tr>
          <th>Nombre</th>
          <th>Apellido</th>
          <th>Año</th>
          <th>Division</th>
          <th>Turno</th>
          <th>Especialidad</th>
          <th>Domicilio</th>
          <th>DNI</th>
          <th>cumple</th>
          <th>E-mail</th>
          <th>Tutor</th>
          <th>DNI</th>
          <th>Telefono</th>
          <th>Accion</th>
        </tr>
      </thead>

      <tbody>
        <tr>
          <td>Tiger</td>
          <td>Nixon</td>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <td>23.456.789</td>
          <th>***</th>
          <td>t.nixon@datatables.net</td>
          <td>Monica</td>
          <td>12.345.657</td>
          <td>1123456789</td>
          <td>
            <a
              class="btn green darken-2 waves-effect waves-light modal-trigger"
              href="#modal2"
            >
              <i class="zmdi zmdi-edit"></i>
            </a>
          </td>
        </tr>
        <tr>
          <td>Garrett</td>
          <td>Winters</td>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <td>12.345.678</td>
          <th>***</th>
          <td>g.winters@datatables.net</td>
          <td>Monica</td>
          <td>12.345.657</td>
          <td>1123456789</td>
          <td>
            <button
              class="btn green darken-2 waves-effect waves-light compact-btn"
            >
              <i class="zmdi zmdi-edit"></i>
            </button>
          </td>
        </tr>
        <tr>
          <td>Ashton</td>
          <td>Cox</td>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <td>21.456.789</td>
          <th>***</th>
          <td>a.cox@datatables.net</td>
          <td>Monica</td>
          <td>12.345.657</td>
          <td>1123456789</td>
          <td>
            <button
              class="btn green darken-2 waves-effect waves-light compact-btn"
            >
              <i class="zmdi zmdi-edit"></i>
            </button>
          </td>
        </tr>
        <tr>
          <td>Cedric</td>
          <td>Kelly</td>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <td>98.765.432</td>
          <th>***</th>
          <td>c.kelly@datatables.net</td>
          <td>Monica</td>
          <td>12.345.657</td>
          <td>1123456789</td>
          <td>
            <button
              class="btn green darken-2 waves-effect waves-light compact-btn"
            >
              <i class="zmdi zmdi-edit"></i>
            </button>
          </td>
        </tr>
        <tr>
          <td>Airi</td>
          <td>Satou</td>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <td>45.678.903</td>
          <th>***</th>
          <td>a.satou@datatables.net</td>
          <td>Monica</td>
          <td>12.345.657</td>
          <td>1123456789</td>
          <td>
            <button
              class="btn green darken-2 waves-effect waves-light compact-btn"
            >
              <i class="zmdi zmdi-edit"></i>
            </button>
          </td>
        </tr>
        <tr>
          <td>Brielle</td>
          <td>Williamson</td>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <td>88.777.654</td>
          <th>***</th>
          <td>b.williamson@datatables.net</td>
          <td>Monica</td>
          <td>12.345.657</td>
          <td>1123456789</td>
          <td>
            <button
              class="btn green darken-2 waves-effect waves-light compact-btn"
            >
              <i class="zmdi zmdi-edit"></i>
            </button>
          </td>
        </tr>
        <tr>
          <td>Herrod</td>
          <td>Chandler</td>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <td>22.345.768</td>
          <th>***</th>
          <td>h.chandler@datatables.net</td>
          <td>Monica</td>
          <td>12.345.657</td>
          <td>1123456789</td>
          <td>
            <button
              class="btn green darken-2 waves-effect waves-light compact-btn"
            >
              <i class="zmdi zmdi-edit"></i>
            </button>
          </td>
        </tr>
        <tr>
          <td>Rhona</td>
          <td>Davidson</td>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <td>45.367.289</td>
          <th>***</th>
          <td>r.davidson@datatables.net</td>
          <td>Monica</td>
          <td>12.345.657</td>
          <td>1123456789</td>
          <td>
            <button
              class="btn green darken-2 waves-effect waves-light compact-btn"
            >
              <i class="zmdi zmdi-edit"></i>
            </button>
          </td>
        </tr>
        <tr>
          <td>Colleen</td>
          <td>Hurst</td>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <td>78.965.432</td>
          <th>***</th>
          <td>c.hurst@datatables.net</td>
          <td>Monica</td>
          <td>12.345.657</td>
          <td>1123456789</td>
          <td>
            <button
              class="btn green darken-2 waves-effect waves-light compact-btn"
            >
              <i class="zmdi zmdi-edit"></i>
            </button>
          </td>
        </tr>
        <tr>
          <td>Sonya</td>
          <td>Frost</td>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <td>11.111.111</td>
          <th>***</th>
          <td>s.frost@datatables.net</td>
          <td>Monica</td>
          <td>12.345.657</td>
          <td>1123456789</td>
          <td>
            <button
              class="btn green darken-2 waves-effect waves-light compact-btn"
            >
              <i class="zmdi zmdi-edit"></i>
            </button>
          </td>
        </tr>
        <tr>
          <td>Jena</td>
          <td>Gaines</td>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <th>***</th>
          <td>22.333.444</td>
          <th>***</th>
          <td>j.gaines@datatables.net</td>
          <td>Monica</td>
          <td>12.345.657</td>
          <td>1123456789</td>
          <td>
            <button
              class="btn green darken-2 waves-effect waves-light compact-btn"
            >
              <i class="zmdi zmdi-edit"></i>
            </button>
          </td>
        </tr>
      </tbody>
    </table>

    <!-- Modal Structure -->
    <div
      id="modal2"
      class="modal modal-fixed mCustomScrollbar"
      data-mcs-theme="dark"
    >
      <div class="modal-content">
        <div class="container">
          <div class="row">
            <h2 class="center-align">Editar Alumno</h2>
            <form class="col s12" action="#">
              <div class="row">
                <div class="input-field col s6">
                  <i class="zmdi zmdi-account-circle prefix"></i>
                  <input
                    id="Name"
                    type="text"
                    class="validate"
                    required="required"
                  />
                  <label for="Name">Nombre</label>
                </div>
                <div class="input-field col s6">
                  <i class="zmdi zmdi-account-circle prefix"></i>
                  <input
                    id="Apellido"
                    type="text"
                    class="validate"
                    required="required"
                  />
                  <label for="Apellico">Apellido</label>
                </div>
                <div class="input-field col s6">
                  <i class="zmdi zmdi-pin-drop prefix"></i>
                  <input
                    id="Domicilio"
                    type="text"
                    class="validate"
                    required="required"
                  />
                  <label for="Domicilio">Domicilio</label>
                </div>
                <div class="input-field col s6">
                  <i class="zmdi zmdi-email prefix"></i>
                  <input
                    id="Email"
                    type="text"
                    class="validate"
                    required="required"
                  />
                  <label for="Email">Email</label>
                </div>
                <div class="input-field col s6">
                  <i class="zmdi zmdi-folder-shared prefix"></i>
                  <input
                    id="DNI"
                    type="tel"
                    class="validate"
                    required="required"
                  />
                  <label for="DNI">DNI</label>
                </div>
                <div class="input-field col s6">
                  <i class="zmdi zmdi-phone prefix"></i>
                  <input
                    id="Telefono"
                    type="tel"
                    class="validate"
                    required="required"
                  />
                  <label for="Telefono">Telefono</label>
                </div>
                <div class="input-field col s12">
                  <i class="zmdi zmdi-calendar prefix"></i>
                  <input
                    id="Nac"
                    type="tel"
                    class="validate"
                    required="required"
                  />
                  <label for="Nac">Fecha de Nacimiento</label>
                </div>
                <div class="input-field col s3">
                  <select>
                    <option value="" disabled selected required="required"
                      >Año</option
                    >
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                  </select>
                </div>
                <div class="input-field col s3">
                  <select>
                    <option value="" disabled selected>Division</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                  </select>
                </div>
                <div class="input-field col s3">
                  <select>
                    <option value="" disabled selected>Turno</option>
                    <option value="1">Mañana</option>
                    <option value="2">Tarde</option>
                    <option value="3">Noche</option>
                  </select>
                </div>

                <div class="input-field col s6">
                  <select>
                    <option value="" disabled selected>Especialidad</option>
                    <option value="1">Ninguna</option>
                    <option value="2">Computacion</option>
                    <option value="3">Mecanica</option>
                    <option value="4">Automotores</option>
                  </select>
                </div>
              </div>
              <h2 class="center-align">Datos de Tutor</h2>
              <div class="input-field col s6">
                <i class="zmdi zmdi-account-circle prefix"></i>
                <input
                  id="Name"
                  type="text"
                  class="validate"
                  required="required"
                />
                <label for="Name">Nombre</label>
              </div>
              <div class="input-field col s6">
                <i class="zmdi zmdi-account-circle prefix"></i>
                <input
                  id="Apellido"
                  type="text"
                  class="validate"
                  required="required"
                />
                <label for="Apellico">Apellido</label>
              </div>
              <div class="input-field col s6">
                <i class="zmdi zmdi-folder-shared prefix"></i>
                <input
                  id="DNI"
                  type="tel"
                  class="validate"
                  required="required"
                />
                <label for="DNI">DNI</label>
              </div>
              <button
                class="waves-effect waves-teal btn-flat col s12"
                style="background-color: #006699;margin-bottom: 5%;"
              >
                Editar Alumno <i class="zmdi zmdi-mail-send"></i>
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $this->load->view('menus/Footer');?>