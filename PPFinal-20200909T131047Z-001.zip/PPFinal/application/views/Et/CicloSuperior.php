<!--Agregar Alumnos a Becas-->
<?php $this->load->view('menus/NavLat');?>
      <div class="row">
        <!--Aca Empiezo-->
        <div class="row">
          <h2 class="center-align">Ciclo Superior</h2>
          <div class="content col s12">
            <ul class="collapsible popout">
              <li>
                <div
                  class="collapsible-header new badge blue darken-3 "
                  style="
                color: white;
            "
                >
                  <i class="material-icons">filter_3</i>3°Año
                </div>
                <div class="collapsible-body" style="background-color: rgb(21, 101, 192);">
                  <span>
                    <!--aca empieza-->
                    <ul class="collapsible popout">
                      <li>
                        <div
                          class="collapsible-header new badge brown darken-1"
                          style="
                            color: white;
                        "
                        >
                          <i class="material-icons">desktop_windows</i
                          >Computacion
                        </div>
                        <div
                          class="collapsible-body"
                          style="background-color: rgb(255, 255, 255);"
                        >
                          <span>
                            <!--aca empieza-->
                            <div class="row">
                              <!--HighlightTable-->
                              <div
                                class="container"
                                style="margin-bottom: 128px;"
                              >
                                <div class="row">
                                  <h2 class="center-align">Materias</h2>
                                  <h3 class="center-align">Clases/Talleres</h3>
                                </div>
                                <table
                                  class="prim col s6"
                                  cellspacing="0"
                                  width="100%"
                                >
                                  <thead>
                                    <tr>
                                      <th>Materias</th>
                                      <th>Nombre Prof.</th>
                                      <th>opciones</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>Lengua y literatura</td>
                                      <td>Winters ------</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-delay="50"
                                          data-position="bottom"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Nolose</td>
                                      <td>Lose</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Ashton</td>
                                      <td>Cox</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Cedric</td>
                                      <td>Kelly</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Airi</td>
                                      <td>Satou</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn btn-exito green darken-2 waves-effect waves-light compact-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Brielle</td>
                                      <td>Williamson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Herrod</td>
                                      <td>Chandler</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Rhona</td>
                                      <td>Davidson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Colleen</td>
                                      <td>Hurst</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Sonya</td>
                                      <td>Frost</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Jena</td>
                                      <td>Gaines</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="done"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                                <table
                                  class="prim col s6"
                                  cellspacing="0"
                                  width="100%"
                                >
                                  <thead>
                                    <tr>
                                      <th>Taller</th>
                                      <th>Nombre Prof.</th>
                                      <th>opciones</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>Carpinteria</td>
                                      <td>Winters ------</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-delay="50"
                                          data-position="bottom"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Nolose</td>
                                      <td>Lose</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Ashton</td>
                                      <td>Cox</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Cedric</td>
                                      <td>Kelly</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Airi</td>
                                      <td>Satou</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn btn-exito green darken-2 waves-effect waves-light compact-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Brielle</td>
                                      <td>Williamson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Herrod</td>
                                      <td>Chandler</td>
                                      <td>
                                        <a
                                          class="btn green darken-2 waves-effect waves-light modal-trigger"
                                          href="#modal3"
                                        >
                                          <i class="zmdi zmdi-edit"></i>
                                        </a>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                                <!-- Modal Structure -->
                                <div
                                  id="modal3"
                                  class="modal modal-fixed mCustomScrollbar"
                                  data-mcs-theme="dark"
                                >
                                  <div class="modal-content">
                                    <div class="container">
                                      <div class="row">
                                        <h2 class="center-align">
                                          Editar Materia
                                        </h2>
                                        <form class="col s12" action="#">
                                          <div class="row">
                                            <div class="input-field col s6">
                                              <i
                                                class="zmdi zmdi-assignment prefix"
                                              ></i>
                                              <input
                                                id="Clase"
                                                type="text"
                                                class="validate"
                                                required="required"
                                              />
                                              <label for="Clase"
                                                >Nombre de Clase</label
                                              >
                                            </div>
                                            <div class="input-field col s6">
                                              <i
                                                class="zmdi zmdi-account-circle prefix"
                                              ></i>
                                              <input
                                                id="Name"
                                                type="text"
                                                class="validate"
                                                required="required"
                                              />
                                              <label for="Name"
                                                >Nombre de Prof.</label
                                              >
                                            </div>
                                            <button
                                            class="waves-effect waves-teal btn-flat col s12"
                                            style="background-color: #006699;margin-bottom: 5%;"
                                          >
                                            Cambiar Materia
                                            <i class="zmdi zmdi-mail-send"></i>
                                          </button>
                                        </form>
                                          </div>

                                          
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <!--aca Termina-->
                          </span>
                        </div>
                      </li>
                      <li>
                        <div
                          class="collapsible-header new badge green darken-1"
                          style="
                          color: white;
                      "
                        >
                          <i class="material-icons">brightness_high</i>Mecanica
                        </div>
                        <div
                          class="collapsible-body"
                          style="background-color: rgb(255, 255, 255);"
                        >
                          <span
                            ><!--aca empieza-->
                            <div class="row">
                              <!--HighlightTable-->
                              <div
                                class="container"
                                style="margin-bottom: 128px;"
                              >
                                <div class="row">
                                  <h2 class="center-align">Materias</h2>
                                  <h3 class="center-align">Clases/Talleres</h3>
                                </div>
                                <table
                                  class="prim col s6"
                                  cellspacing="0"
                                  width="100%"
                                >
                                  <thead>
                                    <tr>
                                      <th>Materias</th>
                                      <th>Nombre Prof.</th>
                                      <th>opciones</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>Lengua y literatura</td>
                                      <td>Winters ------</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-delay="50"
                                          data-position="bottom"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Nolose</td>
                                      <td>Lose</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Ashton</td>
                                      <td>Cox</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Cedric</td>
                                      <td>Kelly</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Airi</td>
                                      <td>Satou</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn btn-exito green darken-2 waves-effect waves-light compact-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Brielle</td>
                                      <td>Williamson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Herrod</td>
                                      <td>Chandler</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Rhona</td>
                                      <td>Davidson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Colleen</td>
                                      <td>Hurst</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Sonya</td>
                                      <td>Frost</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Jena</td>
                                      <td>Gaines</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="done"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                                <table
                                  class="prim col s6"
                                  cellspacing="0"
                                  width="100%"
                                >
                                  <thead>
                                    <tr>
                                      <th>Taller</th>
                                      <th>Nombre Prof.</th>
                                      <th>opciones</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>Carpinteria</td>
                                      <td>Winters ------</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-delay="50"
                                          data-position="bottom"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Nolose</td>
                                      <td>Lose</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Ashton</td>
                                      <td>Cox</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Cedric</td>
                                      <td>Kelly</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Airi</td>
                                      <td>Satou</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn btn-exito green darken-2 waves-effect waves-light compact-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Brielle</td>
                                      <td>Williamson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Herrod</td>
                                      <td>Chandler</td>
                                      <td>
                                        <a
                                          class="btn green darken-2 waves-effect waves-light modal-trigger"
                                          href="#modal3"
                                        >
                                          <i class="zmdi zmdi-edit"></i>
                                        </a>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                                <!-- Modal Structure -->
                                <div
                                  id="modal3"
                                  class="modal modal-fixed mCustomScrollbar"
                                  data-mcs-theme="dark"
                                >
                                  <div class="modal-content">
                                    <div class="container">
                                      <div class="row">
                                        <h2 class="center-align">
                                          Editar Materia
                                        </h2>
                                        <form class="col s12" action="#">
                                          <div class="row">
                                            <div class="input-field col s6">
                                              <i
                                                class="zmdi zmdi-assignment prefix"
                                              ></i>
                                              <input
                                                id="Clase"
                                                type="text"
                                                class="validate"
                                                required="required"
                                              />
                                              <label for="Clase"
                                                >Nombre de Clase</label
                                              >
                                            </div>
                                            <div class="input-field col s6">
                                              <i
                                                class="zmdi zmdi-account-circle prefix"
                                              ></i>
                                              <input
                                                id="Name"
                                                type="text"
                                                class="validate"
                                                required="required"
                                              />
                                              <label for="Name"
                                                >Nombre de Prof.</label
                                              >
                                            </div>
                                            <button
                                            class="waves-effect waves-teal btn-flat col s12"
                                            style="background-color: #006699;margin-bottom: 5%;"
                                          >
                                            Cambiar Materia
                                            <i class="zmdi zmdi-mail-send"></i>
                                          </button>
                                        </form>
                                          </div>

                                         
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <!--aca Termina--></span
                          >
                        </div>
                      </li>
                      <li>
                        <div
                          class="collapsible-header new badge deep-orange darken-1"
                          style="
                          color: white;
                      "
                        >
                          <i class="material-icons">directions_car</i
                          >Automotores
                        </div>
                        <div
                          class="collapsible-body"
                          style="background-color: rgb(255, 255, 255);"
                        >
                          <span>
                            <!--aca empieza-->
                            <div class="row">
                              <!--HighlightTable-->
                              <div
                                class="container"
                                style="margin-bottom: 128px;"
                              >
                                <div class="row">
                                  <h2 class="center-align">Materias</h2>
                                  <h3 class="center-align">Clases/Talleres</h3>
                                </div>
                                <table
                                  class="prim col s6"
                                  cellspacing="0"
                                  width="100%"
                                >
                                  <thead>
                                    <tr>
                                      <th>Materias</th>
                                      <th>Nombre Prof.</th>
                                      <th>opciones</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>Lengua y literatura</td>
                                      <td>Winters ------</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-delay="50"
                                          data-position="bottom"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Nolose</td>
                                      <td>Lose</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Ashton</td>
                                      <td>Cox</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Cedric</td>
                                      <td>Kelly</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Airi</td>
                                      <td>Satou</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn btn-exito green darken-2 waves-effect waves-light compact-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Brielle</td>
                                      <td>Williamson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Herrod</td>
                                      <td>Chandler</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Rhona</td>
                                      <td>Davidson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Colleen</td>
                                      <td>Hurst</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Sonya</td>
                                      <td>Frost</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Jena</td>
                                      <td>Gaines</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="done"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                                <table
                                  class="prim col s6"
                                  cellspacing="0"
                                  width="100%"
                                >
                                  <thead>
                                    <tr>
                                      <th>Taller</th>
                                      <th>Nombre Prof.</th>
                                      <th>opciones</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>Carpinteria</td>
                                      <td>Winters ------</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-delay="50"
                                          data-position="bottom"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Nolose</td>
                                      <td>Lose</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Ashton</td>
                                      <td>Cox</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Cedric</td>
                                      <td>Kelly</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Airi</td>
                                      <td>Satou</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn btn-exito green darken-2 waves-effect waves-light compact-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Brielle</td>
                                      <td>Williamson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Herrod</td>
                                      <td>Chandler</td>
                                      <td>
                                        <a
                                          class="btn green darken-2 waves-effect waves-light modal-trigger"
                                          href="#modal3"
                                        >
                                          <i class="zmdi zmdi-edit"></i>
                                        </a>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                                <!-- Modal Structure -->
                                <div
                                  id="modal3"
                                  class="modal modal-fixed mCustomScrollbar"
                                  data-mcs-theme="dark"
                                >
                                  <div class="modal-content">
                                    <div class="container">
                                      <div class="row">
                                        <h2 class="center-align">
                                          Editar Materia
                                        </h2>
                                        <form class="col s12" action="#">
                                          <div class="row">
                                            <div class="input-field col s6">
                                              <i
                                                class="zmdi zmdi-assignment prefix"
                                              ></i>
                                              <input
                                                id="Clase"
                                                type="text"
                                                class="validate"
                                                required="required"
                                              />
                                              <label for="Clase"
                                                >Nombre de Clase</label
                                              >
                                            </div>
                                            <div class="input-field col s6">
                                              <i
                                                class="zmdi zmdi-account-circle prefix"
                                              ></i>
                                              <input
                                                id="Name"
                                                type="text"
                                                class="validate"
                                                required="required"
                                              />
                                              <label for="Name"
                                                >Nombre de Prof.</label
                                              >
                                            </div>
                                            <button
                                            class="waves-effect waves-teal btn-flat col s12"
                                            style="background-color: #006699;margin-bottom: 5%;"
                                          >
                                            Cambiar Materia
                                            <i class="zmdi zmdi-mail-send"></i>
                                          </button>
                                        </form>
                                          </div>

                                          
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <!--aca Termina-->
                          </span>
                        </div>
                      </li>
                    </ul>

                    <!--aca Termina-->
                  </span>
                </div>
              </li>
              <li>
                <div
                  class="collapsible-header new badge indigo darken-3"
                  style="
                color: white;
            "
                >
                  <i class="material-icons">filter_4</i>4°Año
                </div>
                <div class="collapsible-body" style="background-color: rgb(40, 53, 147)">
                  <span>
                    <!--aca empieza-->
                    <ul class="collapsible popout">
                      <li>
                        <div
                          class="collapsible-header new badge brown darken-1"
                          style="
                            color: white;
                        "
                        >
                          <i class="material-icons">desktop_windows</i
                          >Computacion
                        </div>
                        <div
                          class="collapsible-body"
                          style="background-color: rgb(255, 255, 255);"
                        >
                          <span>
                            <!--aca empieza-->
                            <div class="row">
                              <!--HighlightTable-->
                              <div
                                class="container"
                                style="margin-bottom: 128px;"
                              >
                                <div class="row">
                                  <h2 class="center-align">Materias</h2>
                                  <h3 class="center-align">Clases/Talleres</h3>
                                </div>
                                <table
                                  class="prim col s6"
                                  cellspacing="0"
                                  width="100%"
                                >
                                  <thead>
                                    <tr>
                                      <th>Materias</th>
                                      <th>Nombre Prof.</th>
                                      <th>opciones</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>Lengua y literatura</td>
                                      <td>Winters ------</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-delay="50"
                                          data-position="bottom"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Nolose</td>
                                      <td>Lose</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Ashton</td>
                                      <td>Cox</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Cedric</td>
                                      <td>Kelly</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Airi</td>
                                      <td>Satou</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn btn-exito green darken-2 waves-effect waves-light compact-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Brielle</td>
                                      <td>Williamson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Herrod</td>
                                      <td>Chandler</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Rhona</td>
                                      <td>Davidson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Colleen</td>
                                      <td>Hurst</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Sonya</td>
                                      <td>Frost</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Jena</td>
                                      <td>Gaines</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="done"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                                <table
                                  class="prim col s6"
                                  cellspacing="0"
                                  width="100%"
                                >
                                  <thead>
                                    <tr>
                                      <th>Taller</th>
                                      <th>Nombre Prof.</th>
                                      <th>opciones</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>Carpinteria</td>
                                      <td>Winters ------</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-delay="50"
                                          data-position="bottom"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Nolose</td>
                                      <td>Lose</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Ashton</td>
                                      <td>Cox</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Cedric</td>
                                      <td>Kelly</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Airi</td>
                                      <td>Satou</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn btn-exito green darken-2 waves-effect waves-light compact-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Brielle</td>
                                      <td>Williamson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Herrod</td>
                                      <td>Chandler</td>
                                      <td>
                                        <a
                                          class="btn green darken-2 waves-effect waves-light modal-trigger"
                                          href="#modal3"
                                        >
                                          <i class="zmdi zmdi-edit"></i>
                                        </a>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                                <!-- Modal Structure -->
                                <div
                                  id="modal3"
                                  class="modal modal-fixed mCustomScrollbar"
                                  data-mcs-theme="dark"
                                >
                                  <div class="modal-content">
                                    <div class="container">
                                      <div class="row">
                                        <h2 class="center-align">
                                          Editar Materia
                                        </h2>
                                        <form class="col s12" action="#">
                                          <div class="row">
                                            <div class="input-field col s6">
                                              <i
                                                class="zmdi zmdi-assignment prefix"
                                              ></i>
                                              <input
                                                id="Clase"
                                                type="text"
                                                class="validate"
                                                required="required"
                                              />
                                              <label for="Clase"
                                                >Nombre de Clase</label
                                              >
                                            </div>
                                            <div class="input-field col s6">
                                              <i
                                                class="zmdi zmdi-account-circle prefix"
                                              ></i>
                                              <input
                                                id="Name"
                                                type="text"
                                                class="validate"
                                                required="required"
                                              />
                                              <label for="Name"
                                                >Nombre de Prof.</label
                                              >
                                            </div>
                                            <button
                                            class="waves-effect waves-teal btn-flat col s12"
                                            style="background-color: #006699;margin-bottom: 5%;"
                                          >
                                            Cambiar Materia
                                            <i class="zmdi zmdi-mail-send"></i>
                                          </button>
                                        </form>
                                          </div>

                                         
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <!--aca Termina-->
                          </span>
                        </div>
                      </li>
                      <li>
                        <div
                          class="collapsible-header new badge green darken-1"
                          style="
                          color: white;
                      "
                        >
                          <i class="material-icons">brightness_high</i>Mecanica
                        </div>
                        <div
                          class="collapsible-body"
                          style="background-color: rgb(255, 255, 255);"
                        >
                          <span
                            ><!--aca empieza-->
                            <div class="row">
                              <!--HighlightTable-->
                              <div
                                class="container"
                                style="margin-bottom: 128px;"
                              >
                                <div class="row">
                                  <h2 class="center-align">Materias</h2>
                                  <h3 class="center-align">Clases/Talleres</h3>
                                </div>
                                <table
                                  class="prim col s6"
                                  cellspacing="0"
                                  width="100%"
                                >
                                  <thead>
                                    <tr>
                                      <th>Materias</th>
                                      <th>Nombre Prof.</th>
                                      <th>opciones</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>Lengua y literatura</td>
                                      <td>Winters ------</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-delay="50"
                                          data-position="bottom"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Nolose</td>
                                      <td>Lose</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Ashton</td>
                                      <td>Cox</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Cedric</td>
                                      <td>Kelly</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Airi</td>
                                      <td>Satou</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn btn-exito green darken-2 waves-effect waves-light compact-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Brielle</td>
                                      <td>Williamson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Herrod</td>
                                      <td>Chandler</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Rhona</td>
                                      <td>Davidson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Colleen</td>
                                      <td>Hurst</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Sonya</td>
                                      <td>Frost</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Jena</td>
                                      <td>Gaines</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="done"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                                <table
                                  class="prim col s6"
                                  cellspacing="0"
                                  width="100%"
                                >
                                  <thead>
                                    <tr>
                                      <th>Taller</th>
                                      <th>Nombre Prof.</th>
                                      <th>opciones</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>Carpinteria</td>
                                      <td>Winters ------</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-delay="50"
                                          data-position="bottom"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Nolose</td>
                                      <td>Lose</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Ashton</td>
                                      <td>Cox</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Cedric</td>
                                      <td>Kelly</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Airi</td>
                                      <td>Satou</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn btn-exito green darken-2 waves-effect waves-light compact-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Brielle</td>
                                      <td>Williamson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Herrod</td>
                                      <td>Chandler</td>
                                      <td>
                                        <a
                                          class="btn green darken-2 waves-effect waves-light modal-trigger"
                                          href="#modal3"
                                        >
                                          <i class="zmdi zmdi-edit"></i>
                                        </a>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                                <!-- Modal Structure -->
                                <div
                                  id="modal3"
                                  class="modal modal-fixed mCustomScrollbar"
                                  data-mcs-theme="dark"
                                >
                                  <div class="modal-content">
                                    <div class="container">
                                      <div class="row">
                                        <h2 class="center-align">
                                          Editar Materia
                                        </h2>
                                        <form class="col s12" action="#">
                                          <div class="row">
                                            <div class="input-field col s6">
                                              <i
                                                class="zmdi zmdi-assignment prefix"
                                              ></i>
                                              <input
                                                id="Clase"
                                                type="text"
                                                class="validate"
                                                required="required"
                                              />
                                              <label for="Clase"
                                                >Nombre de Clase</label
                                              >
                                            </div>
                                            <div class="input-field col s6">
                                              <i
                                                class="zmdi zmdi-account-circle prefix"
                                              ></i>
                                              <input
                                                id="Name"
                                                type="text"
                                                class="validate"
                                                required="required"
                                              />
                                              <label for="Name"
                                                >Nombre de Prof.</label
                                              >
                                            </div>
                                            <button
                                            class="waves-effect waves-teal btn-flat col s12"
                                            style="background-color: #006699;margin-bottom: 5%;"
                                          >
                                            Cambiar Materia
                                            <i class="zmdi zmdi-mail-send"></i>
                                          </button>
                                        </form>
                                          </div>

                                          
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <!--aca Termina--></span
                          >
                        </div>
                      </li>
                      <li>
                        <div
                          class="collapsible-header new badge deep-orange darken-1"
                          style="
                          color: white;
                      "
                        >
                          <i class="material-icons">directions_car</i
                          >Automotores
                        </div>
                        <div
                          class="collapsible-body"
                          style="background-color: rgb(255, 255, 255);"
                        >
                          <span>
                            <!--aca empieza-->
                            <div class="row">
                              <!--HighlightTable-->
                              <div
                                class="container"
                                style="margin-bottom: 128px;"
                              >
                                <div class="row">
                                  <h2 class="center-align">Materias</h2>
                                  <h3 class="center-align">Clases/Talleres</h3>
                                </div>
                                <table
                                  class="prim col s6"
                                  cellspacing="0"
                                  width="100%"
                                >
                                  <thead>
                                    <tr>
                                      <th>Materias</th>
                                      <th>Nombre Prof.</th>
                                      <th>opciones</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>Lengua y literatura</td>
                                      <td>Winters ------</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-delay="50"
                                          data-position="bottom"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Nolose</td>
                                      <td>Lose</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Ashton</td>
                                      <td>Cox</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Cedric</td>
                                      <td>Kelly</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Airi</td>
                                      <td>Satou</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn btn-exito green darken-2 waves-effect waves-light compact-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Brielle</td>
                                      <td>Williamson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Herrod</td>
                                      <td>Chandler</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Rhona</td>
                                      <td>Davidson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Colleen</td>
                                      <td>Hurst</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Sonya</td>
                                      <td>Frost</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Jena</td>
                                      <td>Gaines</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="done"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                                <table
                                  class="prim col s6"
                                  cellspacing="0"
                                  width="100%"
                                >
                                  <thead>
                                    <tr>
                                      <th>Taller</th>
                                      <th>Nombre Prof.</th>
                                      <th>opciones</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>Carpinteria</td>
                                      <td>Winters ------</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-delay="50"
                                          data-position="bottom"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Nolose</td>
                                      <td>Lose</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Ashton</td>
                                      <td>Cox</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Cedric</td>
                                      <td>Kelly</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Airi</td>
                                      <td>Satou</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn btn-exito green darken-2 waves-effect waves-light compact-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Brielle</td>
                                      <td>Williamson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Herrod</td>
                                      <td>Chandler</td>
                                      <td>
                                        <a
                                          class="btn green darken-2 waves-effect waves-light modal-trigger"
                                          href="#modal3"
                                        >
                                          <i class="zmdi zmdi-edit"></i>
                                        </a>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                                <!-- Modal Structure -->
                                <div
                                  id="modal3"
                                  class="modal modal-fixed mCustomScrollbar"
                                  data-mcs-theme="dark"
                                >
                                  <div class="modal-content">
                                    <div class="container">
                                      <div class="row">
                                        <h2 class="center-align">
                                          Editar Materia
                                        </h2>
                                        <form class="col s12" action="#">
                                          <div class="row">
                                            <div class="input-field col s6">
                                              <i
                                                class="zmdi zmdi-assignment prefix"
                                              ></i>
                                              <input
                                                id="Clase"
                                                type="text"
                                                class="validate"
                                                required="required"
                                              />
                                              <label for="Clase"
                                                >Nombre de Clase</label
                                              >
                                            </div>
                                            <div class="input-field col s6">
                                              <i
                                                class="zmdi zmdi-account-circle prefix"
                                              ></i>
                                              <input
                                                id="Name"
                                                type="text"
                                                class="validate"
                                                required="required"
                                              />
                                              <label for="Name"
                                                >Nombre de Prof.</label
                                              >
                                            </div>
                                            <button
                                            class="waves-effect waves-teal btn-flat col s12"
                                            style="background-color: #006699;margin-bottom: 5%;"
                                          >
                                            Cambiar Materia
                                            <i class="zmdi zmdi-mail-send"></i>
                                          </button>
                                        </form>
                                          </div>

                                          
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <!--aca Termina-->
                          </span>
                        </div>
                      </li>
                    </ul>

                    <!--aca Termina-->
                  </span>
                </div>
              </li>
              <li>
                <div
                  class="collapsible-header new badge grey darken-3"
                  style="
                color: white;
            "
                >
                  <i class="material-icons">filter_5</i>5°Año
                </div>
                <div class="collapsible-body" style="background-color: rgb(66, 66, 66)">
                  <span>
                    <!--aca empieza-->
                    <ul class="collapsible popout">
                      <li>
                        <div
                          class="collapsible-header new badge brown darken-1"
                          style="
                            color: white;
                        "
                        >
                          <i class="material-icons">desktop_windows</i
                          >Computacion
                        </div>
                        <div
                          class="collapsible-body"
                          style="background-color: rgb(255, 255, 255);"
                        >
                          <span>
                            <!--aca empieza-->
                            <div class="row">
                              <!--HighlightTable-->
                              <div
                                class="container"
                                style="margin-bottom: 128px;"
                              >
                                <div class="row">
                                  <h2 class="center-align">Materias</h2>
                                  <h3 class="center-align">Clases/Talleres</h3>
                                </div>
                                <table
                                  class="prim col s6"
                                  cellspacing="0"
                                  width="100%"
                                >
                                  <thead>
                                    <tr>
                                      <th>Materias</th>
                                      <th>Nombre Prof.</th>
                                      <th>opciones</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>Lengua y literatura</td>
                                      <td>Winters ------</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-delay="50"
                                          data-position="bottom"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Nolose</td>
                                      <td>Lose</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Ashton</td>
                                      <td>Cox</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Cedric</td>
                                      <td>Kelly</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Airi</td>
                                      <td>Satou</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn btn-exito green darken-2 waves-effect waves-light compact-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Brielle</td>
                                      <td>Williamson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Herrod</td>
                                      <td>Chandler</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Rhona</td>
                                      <td>Davidson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Colleen</td>
                                      <td>Hurst</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Sonya</td>
                                      <td>Frost</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Jena</td>
                                      <td>Gaines</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="done"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                                <table
                                  class="prim col s6"
                                  cellspacing="0"
                                  width="100%"
                                >
                                  <thead>
                                    <tr>
                                      <th>Taller</th>
                                      <th>Nombre Prof.</th>
                                      <th>opciones</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>Carpinteria</td>
                                      <td>Winters ------</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-delay="50"
                                          data-position="bottom"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Nolose</td>
                                      <td>Lose</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Ashton</td>
                                      <td>Cox</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Cedric</td>
                                      <td>Kelly</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Airi</td>
                                      <td>Satou</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn btn-exito green darken-2 waves-effect waves-light compact-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Brielle</td>
                                      <td>Williamson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Herrod</td>
                                      <td>Chandler</td>
                                      <td>
                                        <a
                                          class="btn green darken-2 waves-effect waves-light modal-trigger"
                                          href="#modal3"
                                        >
                                          <i class="zmdi zmdi-edit"></i>
                                        </a>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                                <!-- Modal Structure -->
                                <div
                                  id="modal3"
                                  class="modal modal-fixed mCustomScrollbar"
                                  data-mcs-theme="dark"
                                >
                                  <div class="modal-content">
                                    <div class="container">
                                      <div class="row">
                                        <h2 class="center-align">
                                          Editar Materia
                                        </h2>
                                        <form class="col s12" action="#">
                                          <div class="row">
                                            <div class="input-field col s6">
                                              <i
                                                class="zmdi zmdi-assignment prefix"
                                              ></i>
                                              <input
                                                id="Clase"
                                                type="text"
                                                class="validate"
                                                required="required"
                                              />
                                              <label for="Clase"
                                                >Nombre de Clase</label
                                              >
                                            </div>
                                            <div class="input-field col s6">
                                              <i
                                                class="zmdi zmdi-account-circle prefix"
                                              ></i>
                                              <input
                                                id="Name"
                                                type="text"
                                                class="validate"
                                                required="required"
                                              />
                                              <label for="Name"
                                                >Nombre de Prof.</label
                                              >
                                            </div>
                                            <button
                                            class="waves-effect waves-teal btn-flat col s12"
                                            style="background-color: #006699;margin-bottom: 5%;"
                                          >
                                            Cambiar Materia
                                            <i class="zmdi zmdi-mail-send"></i>
                                          </button>
                                        </form>
                                          </div>

                                          
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <!--aca Termina-->
                          </span>
                        </div>
                      </li>
                      <li>
                        <div
                          class="collapsible-header new badge green darken-1"
                          style="
                          color: white;
                      "
                        >
                          <i class="material-icons">brightness_high</i>Mecanica
                        </div>
                        <div
                          class="collapsible-body"
                          style="background-color: rgb(255, 255, 255);"
                        >
                          <span
                            ><!--aca empieza-->
                            <div class="row">
                              <!--HighlightTable-->
                              <div
                                class="container"
                                style="margin-bottom: 128px;"
                              >
                                <div class="row">
                                  <h2 class="center-align">Materias</h2>
                                  <h3 class="center-align">Clases/Talleres</h3>
                                </div>
                                <table
                                  class="prim col s6"
                                  cellspacing="0"
                                  width="100%"
                                >
                                  <thead>
                                    <tr>
                                      <th>Materias</th>
                                      <th>Nombre Prof.</th>
                                      <th>opciones</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>Lengua y literatura</td>
                                      <td>Winters ------</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-delay="50"
                                          data-position="bottom"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Nolose</td>
                                      <td>Lose</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Ashton</td>
                                      <td>Cox</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Cedric</td>
                                      <td>Kelly</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Airi</td>
                                      <td>Satou</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn btn-exito green darken-2 waves-effect waves-light compact-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Brielle</td>
                                      <td>Williamson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Herrod</td>
                                      <td>Chandler</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Rhona</td>
                                      <td>Davidson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Colleen</td>
                                      <td>Hurst</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Sonya</td>
                                      <td>Frost</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Jena</td>
                                      <td>Gaines</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="done"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                                <table
                                  class="prim col s6"
                                  cellspacing="0"
                                  width="100%"
                                >
                                  <thead>
                                    <tr>
                                      <th>Taller</th>
                                      <th>Nombre Prof.</th>
                                      <th>opciones</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>Carpinteria</td>
                                      <td>Winters ------</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-delay="50"
                                          data-position="bottom"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Nolose</td>
                                      <td>Lose</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Ashton</td>
                                      <td>Cox</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Cedric</td>
                                      <td>Kelly</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Airi</td>
                                      <td>Satou</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn btn-exito green darken-2 waves-effect waves-light compact-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Brielle</td>
                                      <td>Williamson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Herrod</td>
                                      <td>Chandler</td>
                                      <td>
                                        <a
                                          class="btn green darken-2 waves-effect waves-light modal-trigger"
                                          href="#modal3"
                                        >
                                          <i class="zmdi zmdi-edit"></i>
                                        </a>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                                <!-- Modal Structure -->
                                <div
                                  id="modal3"
                                  class="modal modal-fixed mCustomScrollbar"
                                  data-mcs-theme="dark"
                                >
                                  <div class="modal-content">
                                    <div class="container">
                                      <div class="row">
                                        <h2 class="center-align">
                                          Editar Materia
                                        </h2>
                                        <form class="col s12" action="#">
                                          <div class="row">
                                            <div class="input-field col s6">
                                              <i
                                                class="zmdi zmdi-assignment prefix"
                                              ></i>
                                              <input
                                                id="Clase"
                                                type="text"
                                                class="validate"
                                                required="required"
                                              />
                                              <label for="Clase"
                                                >Nombre de Clase</label
                                              >
                                            </div>
                                            <div class="input-field col s6">
                                              <i
                                                class="zmdi zmdi-account-circle prefix"
                                              ></i>
                                              <input
                                                id="Name"
                                                type="text"
                                                class="validate"
                                                required="required"
                                              />
                                              <label for="Name"
                                                >Nombre de Prof.</label
                                              >
                                            </div>
                                            <button
                                            class="waves-effect waves-teal btn-flat col s12"
                                            style="background-color: #006699;margin-bottom: 5%;"
                                          >
                                            Cambiar Materia
                                            <i class="zmdi zmdi-mail-send"></i>
                                          </button>
                                        </form>
                                          </div>

                                          
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <!--aca Termina--></span
                          >
                        </div>
                      </li>
                      <li>
                        <div
                          class="collapsible-header new badge deep-orange darken-1"
                          style="
                          color: white;
                      "
                        >
                          <i class="material-icons">directions_car</i
                          >Automotores
                        </div>
                        <div
                          class="collapsible-body"
                          style="background-color: rgb(255, 255, 255);"
                        >
                          <span>
                            <!--aca empieza-->
                            <div class="row">
                              <!--HighlightTable-->
                              <div
                                class="container"
                                style="margin-bottom: 128px;"
                              >
                                <div class="row">
                                  <h2 class="center-align">Materias</h2>
                                  <h3 class="center-align">Clases/Talleres</h3>
                                </div>
                                <table
                                  class="prim col s6"
                                  cellspacing="0"
                                  width="100%"
                                >
                                  <thead>
                                    <tr>
                                      <th>Materias</th>
                                      <th>Nombre Prof.</th>
                                      <th>opciones</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>Lengua y literatura</td>
                                      <td>Winters ------</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-delay="50"
                                          data-position="bottom"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Nolose</td>
                                      <td>Lose</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Ashton</td>
                                      <td>Cox</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Cedric</td>
                                      <td>Kelly</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Airi</td>
                                      <td>Satou</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn btn-exito green darken-2 waves-effect waves-light compact-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Brielle</td>
                                      <td>Williamson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Herrod</td>
                                      <td>Chandler</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Rhona</td>
                                      <td>Davidson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Colleen</td>
                                      <td>Hurst</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Sonya</td>
                                      <td>Frost</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Jena</td>
                                      <td>Gaines</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="done"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                                <table
                                  class="prim col s6"
                                  cellspacing="0"
                                  width="100%"
                                >
                                  <thead>
                                    <tr>
                                      <th>Taller</th>
                                      <th>Nombre Prof.</th>
                                      <th>opciones</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>Carpinteria</td>
                                      <td>Winters ------</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-delay="50"
                                          data-position="bottom"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Nolose</td>
                                      <td>Lose</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Ashton</td>
                                      <td>Cox</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Cedric</td>
                                      <td>Kelly</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Airi</td>
                                      <td>Satou</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn btn-exito green darken-2 waves-effect waves-light compact-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Brielle</td>
                                      <td>Williamson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Herrod</td>
                                      <td>Chandler</td>
                                      <td>
                                        <a
                                          class="btn green darken-2 waves-effect waves-light modal-trigger"
                                          href="#modal3"
                                        >
                                          <i class="zmdi zmdi-edit"></i>
                                        </a>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                                <!-- Modal Structure -->
                                <div
                                  id="modal3"
                                  class="modal modal-fixed mCustomScrollbar"
                                  data-mcs-theme="dark"
                                >
                                  <div class="modal-content">
                                    <div class="container">
                                      <div class="row">
                                        <h2 class="center-align">
                                          Editar Materia
                                        </h2>
                                        <form class="col s12" action="#">
                                          <div class="row">
                                            <div class="input-field col s6">
                                              <i
                                                class="zmdi zmdi-assignment prefix"
                                              ></i>
                                              <input
                                                id="Clase"
                                                type="text"
                                                class="validate"
                                                required="required"
                                              />
                                              <label for="Clase"
                                                >Nombre de Clase</label
                                              >
                                            </div>
                                            <div class="input-field col s6">
                                              <i
                                                class="zmdi zmdi-account-circle prefix"
                                              ></i>
                                              <input
                                                id="Name"
                                                type="text"
                                                class="validate"
                                                required="required"
                                              />
                                              <label for="Name"
                                                >Nombre de Prof.</label
                                              >
                                            </div>
                                            <button
                                            class="waves-effect waves-teal btn-flat col s12"
                                            style="background-color: #006699;margin-bottom: 5%;"
                                          >
                                            Cambiar Materia
                                            <i class="zmdi zmdi-mail-send"></i>
                                          </button>
                                        </form>
                                          </div>

                                          
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <!--aca Termina-->
                          </span>
                        </div>
                      </li>
                    </ul>

                    <!--aca Termina-->
                  </span>
                </div>
              </li>
              <li>
                <div
                  class="collapsible-header new badge  blue-grey darken-4"
                  style="
                color: white;
            "
                >
                  <i class="material-icons">filter_6</i>6°Año
                </div>
                <div
                  class="collapsible-body"
                  style="background-color: rgb(38, 50, 56);"
                >
                  <span>
                    <!--aca empieza-->
                    <ul class="collapsible popout">
                      <li>
                        <div
                          class="collapsible-header new badge brown darken-1"
                          style="
                color: white;
            "
                        >
                          <i class="material-icons">desktop_windows</i
                          >Computacion
                        </div>
                        <div
                          class="collapsible-body"
                          style="background-color: rgb(255, 255, 255);"
                        >
                          <span>
                            <!--aca empieza-->
                            <div class="row">
                              <!--HighlightTable-->
                              <div
                                class="container"
                                style="margin-bottom: 128px;"
                              >
                                <div class="row">
                                  <h2 class="center-align">Materias</h2>
                                  <h3 class="center-align">Clases/Talleres</h3>
                                </div>
                                <table
                                  class="prim col s6"
                                  cellspacing="0"
                                  width="100%"
                                >
                                  <thead>
                                    <tr>
                                      <th>Materias</th>
                                      <th>Nombre Prof.</th>
                                      <th>opciones</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>Lengua y literatura</td>
                                      <td>Winters ------</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-delay="50"
                                          data-position="bottom"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Nolose</td>
                                      <td>Lose</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Ashton</td>
                                      <td>Cox</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Cedric</td>
                                      <td>Kelly</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Airi</td>
                                      <td>Satou</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn btn-exito green darken-2 waves-effect waves-light compact-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Brielle</td>
                                      <td>Williamson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Herrod</td>
                                      <td>Chandler</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Rhona</td>
                                      <td>Davidson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Colleen</td>
                                      <td>Hurst</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Sonya</td>
                                      <td>Frost</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Jena</td>
                                      <td>Gaines</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="done"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                                <table
                                  class="prim col s6"
                                  cellspacing="0"
                                  width="100%"
                                >
                                  <thead>
                                    <tr>
                                      <th>Taller</th>
                                      <th>Nombre Prof.</th>
                                      <th>opciones</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>Carpinteria</td>
                                      <td>Winters ------</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-delay="50"
                                          data-position="bottom"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Nolose</td>
                                      <td>Lose</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Ashton</td>
                                      <td>Cox</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Cedric</td>
                                      <td>Kelly</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Airi</td>
                                      <td>Satou</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn btn-exito green darken-2 waves-effect waves-light compact-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Brielle</td>
                                      <td>Williamson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Herrod</td>
                                      <td>Chandler</td>
                                      <td>
                                        <a
                                          class="btn green darken-2 waves-effect waves-light modal-trigger"
                                          href="#modal3"
                                        >
                                          <i class="zmdi zmdi-edit"></i>
                                        </a>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                                <!-- Modal Structure -->
                                <div
                                  id="modal3"
                                  class="modal modal-fixed mCustomScrollbar"
                                  data-mcs-theme="dark"
                                >
                                  <div class="modal-content">
                                    <div class="container">
                                      <div class="row">
                                        <h2 class="center-align">
                                          Editar Materia
                                        </h2>
                                        <form class="col s12" action="#">
                                          <div class="row">
                                            <div class="input-field col s6">
                                              <i
                                                class="zmdi zmdi-assignment prefix"
                                              ></i>
                                              <input
                                                id="Clase"
                                                type="text"
                                                class="validate"
                                                required="required"
                                              />
                                              <label for="Clase"
                                                >Nombre de Clase</label
                                              >
                                            </div>
                                            <div class="input-field col s6">
                                              <i
                                                class="zmdi zmdi-account-circle prefix"
                                              ></i>
                                              <input
                                                id="Name"
                                                type="text"
                                                class="validate"
                                                required="required"
                                              />
                                              <label for="Name"
                                                >Nombre de Prof.</label
                                              >
                                            </div>
                                            <button
                                            class="waves-effect waves-teal btn-flat col s12"
                                            style="background-color: #006699;margin-bottom: 5%;"
                                          >
                                            Cambiar Materia
                                            <i class="zmdi zmdi-mail-send"></i>
                                          </button>
                                        </form>
                                          </div>

                                          
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <!--aca Termina-->
                          </span>
                        </div>
                      </li>
                      <li>
                        <div
                          class="collapsible-header new badge green darken-1"
                          style="
              color: white;
          "
                        >
                          <i class="material-icons">brightness_high</i>Mecanica
                        </div>
                        <div
                          class="collapsible-body"
                          style="background-color: rgb(255, 255, 255);"
                        >
                          <span
                            ><!--aca empieza-->
                            <div class="row">
                              <!--HighlightTable-->
                              <div
                                class="container"
                                style="margin-bottom: 128px;"
                              >
                                <div class="row">
                                  <h2 class="center-align">Materias</h2>
                                  <h3 class="center-align">Clases/Talleres</h3>
                                </div>
                                <table
                                  class="prim col s6"
                                  cellspacing="0"
                                  width="100%"
                                >
                                  <thead>
                                    <tr>
                                      <th>Materias</th>
                                      <th>Nombre Prof.</th>
                                      <th>opciones</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>Lengua y literatura</td>
                                      <td>Winters ------</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-delay="50"
                                          data-position="bottom"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Nolose</td>
                                      <td>Lose</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Ashton</td>
                                      <td>Cox</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Cedric</td>
                                      <td>Kelly</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Airi</td>
                                      <td>Satou</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn btn-exito green darken-2 waves-effect waves-light compact-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Brielle</td>
                                      <td>Williamson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Herrod</td>
                                      <td>Chandler</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Rhona</td>
                                      <td>Davidson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Colleen</td>
                                      <td>Hurst</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Sonya</td>
                                      <td>Frost</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Jena</td>
                                      <td>Gaines</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="done"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                                <table
                                  class="prim col s6"
                                  cellspacing="0"
                                  width="100%"
                                >
                                  <thead>
                                    <tr>
                                      <th>Taller</th>
                                      <th>Nombre Prof.</th>
                                      <th>opciones</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>Carpinteria</td>
                                      <td>Winters ------</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-delay="50"
                                          data-position="bottom"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Nolose</td>
                                      <td>Lose</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Ashton</td>
                                      <td>Cox</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Cedric</td>
                                      <td>Kelly</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Airi</td>
                                      <td>Satou</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn btn-exito green darken-2 waves-effect waves-light compact-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Brielle</td>
                                      <td>Williamson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Herrod</td>
                                      <td>Chandler</td>
                                      <td>
                                        <a
                                          class="btn green darken-2 waves-effect waves-light modal-trigger"
                                          href="#modal3"
                                        >
                                          <i class="zmdi zmdi-edit"></i>
                                        </a>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                                <!-- Modal Structure -->
                                <div
                                  id="modal3"
                                  class="modal modal-fixed mCustomScrollbar"
                                  data-mcs-theme="dark"
                                >
                                  <div class="modal-content">
                                    <div class="container">
                                      <div class="row">
                                        <h2 class="center-align">
                                          Editar Materia
                                        </h2>
                                        <form class="col s12" action="#">
                                          <div class="row">
                                            <div class="input-field col s6">
                                              <i
                                                class="zmdi zmdi-assignment prefix"
                                              ></i>
                                              <input
                                                id="Clase"
                                                type="text"
                                                class="validate"
                                                required="required"
                                              />
                                              <label for="Clase"
                                                >Nombre de Clase</label
                                              >
                                            </div>
                                            <div class="input-field col s6">
                                              <i
                                                class="zmdi zmdi-account-circle prefix"
                                              ></i>
                                              <input
                                                id="Name"
                                                type="text"
                                                class="validate"
                                                required="required"
                                              />
                                              <label for="Name"
                                                >Nombre de Prof.</label
                                              >
                                            </div>
                                            <button
                                            class="waves-effect waves-teal btn-flat col s12"
                                            style="background-color: #006699;margin-bottom: 5%;"
                                          >
                                            Cambiar Materia
                                            <i class="zmdi zmdi-mail-send"></i>
                                          </button>
                                        </form>
                                          </div>

                                          
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <!--aca Termina--></span
                          >
                        </div>
                      </li>
                      <li>
                        <div
                          class="collapsible-header new badge deep-orange darken-1"
                          style="
              color: white;
          "
                        >
                          <i class="material-icons">directions_car</i
                          >Automotores
                        </div>
                        <div
                          class="collapsible-body"
                          style="background-color: rgb(255, 255, 255);"
                        >
                          <span>
                            <!--aca empieza-->
                            <div class="row">
                              <!--HighlightTable-->
                              <div
                                class="container"
                                style="margin-bottom: 128px;"
                              >
                                <div class="row">
                                  <h2 class="center-align">Materias</h2>
                                  <h3 class="center-align">Clases/Talleres</h3>
                                </div>
                                <table
                                  class="prim col s6"
                                  cellspacing="0"
                                  width="100%"
                                >
                                  <thead>
                                    <tr>
                                      <th>Materias</th>
                                      <th>Nombre Prof.</th>
                                      <th>opciones</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>Lengua y literatura</td>
                                      <td>Winters ------</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-delay="50"
                                          data-position="bottom"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Nolose</td>
                                      <td>Lose</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Ashton</td>
                                      <td>Cox</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Cedric</td>
                                      <td>Kelly</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Airi</td>
                                      <td>Satou</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn btn-exito green darken-2 waves-effect waves-light compact-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Brielle</td>
                                      <td>Williamson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Herrod</td>
                                      <td>Chandler</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Rhona</td>
                                      <td>Davidson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Colleen</td>
                                      <td>Hurst</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Sonya</td>
                                      <td>Frost</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Jena</td>
                                      <td>Gaines</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="done"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                                <table
                                  class="prim col s6"
                                  cellspacing="0"
                                  width="100%"
                                >
                                  <thead>
                                    <tr>
                                      <th>Taller</th>
                                      <th>Nombre Prof.</th>
                                      <th>opciones</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    <tr>
                                      <td>Carpinteria</td>
                                      <td>Winters ------</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-delay="50"
                                          data-position="bottom"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Nolose</td>
                                      <td>Lose</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Ashton</td>
                                      <td>Cox</td>
                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Cedric</td>
                                      <td>Kelly</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Airi</td>
                                      <td>Satou</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn btn-exito green darken-2 waves-effect waves-light compact-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Brielle</td>
                                      <td>Williamson</td>

                                      <td>
                                        <a
                                          href="#"
                                          class="btn green darken-2 waves-effect waves-light compact2-btn"
                                          data-position="bottom"
                                          data-delay="50"
                                          data-tooltip="check"
                                          ><i class="zmdi zmdi-check"></i
                                        ></a>
                                      </td>
                                    </tr>
                                    <tr>
                                      <td>Herrod</td>
                                      <td>Chandler</td>
                                      <td>
                                        <a
                                          class="btn green darken-2 waves-effect waves-light modal-trigger"
                                          href="#modal3"
                                        >
                                          <i class="zmdi zmdi-edit"></i>
                                        </a>
                                      </td>
                                    </tr>
                                  </tbody>
                                </table>
                                <!-- Modal Structure -->
                                <div
                                  id="modal3"
                                  class="modal modal-fixed mCustomScrollbar"
                                  data-mcs-theme="dark"
                                >
                                  <div class="modal-content">
                                    <div class="container">
                                      <div class="row">
                                        <h2 class="center-align">
                                          Editar Materia
                                        </h2>
                                        <form class="col s12" action="#">
                                          <div class="row">
                                            <div class="input-field col s6">
                                              <i
                                                class="zmdi zmdi-assignment prefix"
                                              ></i>
                                              <input
                                                id="Clase"
                                                type="text"
                                                class="validate"
                                                required="required"
                                              />
                                              <label for="Clase"
                                                >Nombre de Clase</label
                                              >
                                            </div>
                                            <div class="input-field col s6">
                                              <i
                                                class="zmdi zmdi-account-circle prefix"
                                              ></i>
                                              <input
                                                id="Name"
                                                type="text"
                                                class="validate"
                                                required="required"
                                              />
                                              <label for="Name"
                                                >Nombre de Prof.</label
                                              >
                                            </div>
                                            <button
                                            class="waves-effect waves-teal btn-flat col s12"
                                            style="background-color: #006699;margin-bottom: 5%;"
                                          >
                                            Cambiar Materia
                                            <i class="zmdi zmdi-mail-send"></i>
                                          </button>
                                        </form>
                                          </div>

                                          
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <!--aca Termina-->
                          </span>
                        </div>
                      </li>
                    </ul>
                    <!--aca Termina-->
                  </span>
                </div>
              </li>
            </ul>
          </div>
        </div>
      <!--aca termino-->
      <?php $this->load->view('menus/Footer');?>