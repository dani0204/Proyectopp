<?php $this->load->view('menus/NavLat');?>
<div class="row">
        <!-- Tiles -->
        <article class="col s12">
          <div class="full-width center-align" style="margin: 40px 0;">
            <div class="tile">
              <div class="tile-icon"><i class="zmdi zmdi-mail-send"></i></div>
              <div class="tile-caption">
                <span class="center-align">77</span>
                <p class="center-align">Lorem ipsum</p>
              </div>
              <a href="#" class="tile-link waves-effect waves-light"
                >View Details &nbsp; <i class="zmdi zmdi-caret-right-circle"></i
              ></a>
            </div>
            <div class="tile">
              <div class="tile-icon">
                <i class="zmdi zmdi-shopping-cart"></i>
              </div>
              <div class="tile-caption">
                <span class="center-align">99</span>
                <p class="center-align">Lorem ipsum</p>
              </div>
              <a href="#" class="tile-link waves-effect waves-light"
                >View Details &nbsp; <i class="zmdi zmdi-caret-right-circle"></i
              ></a>
            </div>
            <div class="tile">
              <div class="tile-icon"><i class="zmdi zmdi-card"></i></div>
              <div class="tile-caption">
                <span class="center-align">17</span>
                <p class="center-align">Lorem ipsum</p>
              </div>
              <a href="#" class="tile-link waves-effect waves-light"
                >View Details &nbsp; <i class="zmdi zmdi-caret-right-circle"></i
              ></a>
            </div>
          </div>
        </article>

        <!-- Timeline -->
        <article class="col s12">
          <h4>Responsive Timeline</h4>
          <hr />
          <ul class="timeline">
            <li>
              <div class="timeline-badge bg-info">
                <i class="zmdi zmdi-twitter"></i>
              </div>
              <div class="timeline-panel">
                <div class="timeline-heading">
                  <h5 class="timeline-title">Lorem ipsum dolor</h5>
                  <p>
                    <small class="text-muted"
                      ><i class="zmdi zmdi-time"></i> 11 hours ago via
                      Twitter</small
                    >
                  </p>
                </div>
                <div class="timeline-body">
                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                    Libero laboriosam dolor perspiciatis omnis exercitationem.
                    Beatae, officia pariatur? Est cum veniam excepturi. Maiores
                    praesentium, porro voluptas suscipit facere rem dicta,
                    debitis.
                  </p>
                </div>
              </div>
            </li>
            <li class="timeline-inverted">
              <div class="timeline-badge bg-primary">
                <i class="zmdi zmdi-facebook"></i>
              </div>
              <div class="timeline-panel">
                <div class="timeline-heading">
                  <h5 class="timeline-title">Lorem ipsum dolor</h5>
                  <p>
                    <small class="text-muted"
                      ><i class="zmdi zmdi-time"></i> 10 hours ago via
                      Facebook</small
                    >
                  </p>
                </div>
                <div class="timeline-body">
                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                    Autem dolorem quibusdam, tenetur commodi provident cumque
                    magni voluptatem libero, quis rerum. Fugiat esse debitis
                    optio, tempore. Animi officiis alias, officia repellendus.
                  </p>
                </div>
              </div>
            </li>
            <li>
              <div class="timeline-badge bg-success">
                <i class="zmdi zmdi-whatsapp"></i>
              </div>
              <div class="timeline-panel">
                <div class="timeline-heading">
                  <h5 class="timeline-title success">Lorem ipsum dolor</h5>
                  <p>
                    <small class="text-muted"
                      ><i class="zmdi zmdi-time"></i> 9 hours ago via
                      Whatsapp</small
                    >
                  </p>
                </div>
                <div class="timeline-body">
                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                    Libero laboriosam dolor perspiciatis omnis exercitationem.
                    Beatae, officia pariatur? Est cum veniam excepturi. Maiores
                    praesentium, porro voluptas suscipit facere rem dicta,
                    debitis.
                  </p>
                </div>
              </div>
            </li>
            <li class="timeline-inverted">
              <div class="timeline-badge bg-danger">
                <i class="zmdi zmdi-pinterest"></i>
              </div>
              <div class="timeline-panel">
                <div class="timeline-heading">
                  <h5 class="timeline-title">Lorem ipsum dolor</h5>
                  <p>
                    <small class="text-muted"
                      ><i class="zmdi zmdi-time"></i> 8 hours ago via
                      Pinterest</small
                    >
                  </p>
                </div>
                <div class="timeline-body">
                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                    Autem dolorem quibusdam, tenetur commodi provident cumque
                    magni voluptatem libero, quis rerum. Fugiat esse debitis
                    optio, tempore. Animi officiis alias, officia repellendus.
                  </p>
                </div>
              </div>
            </li>
          </ul>
        </article>
      </div>
      <?php $this->load->view('menus/Footer');?>