<!--Confirmar Usuario-->
<?php $this->load->view('menus/NavLat');?>

<div class="row">
  <!--HighlightTable-->
  <div class="container" style="margin-bottom: 128px;">
    <div class="row">
      <h2 class="center-align">Aprobacion de Usuarios</h2>
    </div>
    <table id="example" class="prim" cellspacing="0" width="100%">
      <thead>
        <tr>
          <th>Nombre</th>
          <th>Apellido</th>
          <th>Email</th>
          <th>Permiso</th>
          <th>tipo</th>
          <th>opciones</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>Garrett</td>
          <td>Winters</td>
          <td>***</td>
          <td class="sorting_1">
            <span class="new badge orange" data-badge-caption="">Falta</span>
          </td>
          <td style="width: 30%;">
            <select>
              <option value="" disabled selected>ninguno</option>
              <option value="1">Preceptor</option>
              <option value="2">Docente</option>
              <option value="3">Admin</option>
              <option value="3">nose</option>
            </select>
          </td>
          <td>
            <a class="btn red darken-2 waves-effect waves-light compact-btn">
              <i class="zmdi zmdi-delete"></i>
            </a>
            <a
              href="#"
              class="btn green darken-2 waves-effect waves-light compact2-btn"
              data-delay="50"
              data-position="bottom"
              data-tooltip="check"
              ><i class="zmdi zmdi-check"></i
            ></a>
          </td>
        </tr>
        <tr>
          <td>Nolose</td>
          <td>Lose</td>
          <td>***</td>
          <td class="sorting_1">
            <span class="new badge orange" data-badge-caption="">Falta</span>
          </td>
          <td>
            <select>
              <option value="" disabled selected>ninguno</option>
              <option value="1">Preceptor</option>
              <option value="2">Docente</option>
              <option value="3">Admin</option>
              <option value="3">nose</option>
            </select>
          </td>
          <td>
            <a class="btn red darken-2 waves-effect waves-light compact-btn">
              <i class="zmdi zmdi-delete"></i>
            </a>
            <a
              href="#"
              class="btn green darken-2 waves-effect waves-light compact2-btn"
              data-position="bottom"
              data-delay="50"
              data-tooltip="check"
              ><i class="zmdi zmdi-check"></i
            ></a>
          </td>
        </tr>
        <tr>
          <td>Ashton</td>
          <td>Cox</td>
          <td>***</td>
          <td class="sorting_1">
            <span class="new badge orange" data-badge-caption="">Falta</span>
          </td>
          <td>
            <select>
              <option value="" disabled selected>ninguno</option>
              <option value="1">Preceptor</option>
              <option value="2">Docente</option>
              <option value="3">Admin</option>
              <option value="3">nose</option>
            </select>
          </td>
          <td>
            <a class="btn red darken-2 waves-effect waves-light compact-btn">
              <i class="zmdi zmdi-delete"></i>
            </a>
            <a
              href="#"
              class="btn green darken-2 waves-effect waves-light compact2-btn"
              data-position="bottom"
              data-delay="50"
              data-tooltip="check"
              ><i class="zmdi zmdi-check"></i
            ></a>
          </td>
        </tr>
        <tr>
          <td>Cedric</td>
          <td>Kelly</td>
          <td>***</td>
          <td class="sorting_1">
            <span class="new badge orange" data-badge-caption="">Falta</span>
          </td>
          <td>
            <select>
              <option value="" disabled selected>ninguno</option>
              <option value="1">Preceptor</option>
              <option value="2">Docente</option>
              <option value="3">Admin</option>
              <option value="3">nose</option>
            </select>
          </td>
          <td>
            <a class="btn red darken-2 waves-effect waves-light compact-btn">
              <i class="zmdi zmdi-delete"></i>
            </a>
            <a
              href="#"
              class="btn green darken-2 waves-effect waves-light compact2-btn"
              data-position="bottom"
              data-delay="50"
              data-tooltip="check"
              ><i class="zmdi zmdi-check"></i
            ></a>
          </td>
        </tr>
        <tr>
          <td>Airi</td>
          <td>Satou</td>
          <td>***</td>
          <td class="sorting_1">
            <span class="new badge orange" data-badge-caption="">Falta</span>
          </td>
          <td>
            <select>
              <option value="" disabled selected>ninguno</option>
              <option value="1">Preceptor</option>
              <option value="2">Docente</option>
              <option value="3">Admin</option>
              <option value="3">nose</option>
            </select>
          </td>
          <td>
            <a
              class="btn btn-peligro red darken-2 waves-effect waves-light compact-btn"
            >
              <i class="zmdi zmdi-delete"></i>
            </a>
            <a
              href="#"
              class="btn btn-exito green darken-2 waves-effect waves-light compact-btn"
              data-position="bottom"
              data-delay="50"
              data-tooltip="check"
              ><i class="zmdi zmdi-check"></i
            ></a>
          </td>
        </tr>
        <tr>
          <td>Brielle</td>
          <td>Williamson</td>
          <td>***</td>
          <td class="sorting_1">
            <span class="new badge orange" data-badge-caption="">Falta</span>
          </td>
          <td>
            <select>
              <option value="" disabled selected>ninguno</option>
              <option value="1">Preceptor</option>
              <option value="2">Docente</option>
              <option value="3">Admin</option>
              <option value="3">nose</option>
            </select>
          </td>
          <td>
            <a class="btn red darken-2 waves-effect waves-light compact-btn">
              <i class="zmdi zmdi-delete"></i>
            </a>
            <a
              href="#"
              class="btn green darken-2 waves-effect waves-light compact2-btn"
              data-position="bottom"
              data-delay="50"
              data-tooltip="check"
              ><i class="zmdi zmdi-check"></i
            ></a>
          </td>
        </tr>
        <tr>
          <td>Herrod</td>
          <td>Chandler</td>
          <td>***</td>
          <td class="sorting_1">
            <span class="new badge orange" data-badge-caption="">Falta</span>
          </td>
          <td>
            <select>
              <option value="" disabled selected>ninguno</option>
              <option value="1">Preceptor</option>
              <option value="2">Docente</option>
              <option value="3">Admin</option>
              <option value="3">nose</option>
            </select>
          </td>
          <td>
            <a class="btn red darken-2 waves-effect waves-light compact-btn">
              <i class="zmdi zmdi-delete"></i>
            </a>
            <a
              href="#"
              class="btn green darken-2 waves-effect waves-light compact2-btn"
              data-position="bottom"
              data-delay="50"
              data-tooltip="check"
              ><i class="zmdi zmdi-check"></i
            ></a>
          </td>
        </tr>
        <tr>
          <td>Rhona</td>
          <td>Davidson</td>
          <td>***</td>
          <td class="sorting_1">
            <span class="new badge orange" data-badge-caption="">Falta</span>
          </td>
          <td>
            <select>
              <option value="" disabled selected>ninguno</option>
              <option value="1">Preceptor</option>
              <option value="2">Docente</option>
              <option value="3">Admin</option>
              <option value="3">nose</option>
            </select>
          </td>
          <td>
            <a class="btn red darken-2 waves-effect waves-light compact-btn">
              <i class="zmdi zmdi-delete"></i>
            </a>
            <a
              href="#"
              class="btn green darken-2 waves-effect waves-light compact2-btn"
              data-position="bottom"
              data-delay="50"
              data-tooltip="check"
              ><i class="zmdi zmdi-check"></i
            ></a>
          </td>
        </tr>
        <tr>
          <td>Colleen</td>
          <td>Hurst</td>
          <td>***</td>
          <td class="sorting_1">
            <span class="new badge orange" data-badge-caption="">Falta</span>
          </td>
          <td>
            <select>
              <option value="" disabled selected>ninguno</option>
              <option value="1">Preceptor</option>
              <option value="2">Docente</option>
              <option value="3">Admin</option>
              <option value="3">nose</option>
            </select>
          </td>
          <td>
            <a class="btn red darken-2 waves-effect waves-light compact-btn">
              <i class="zmdi zmdi-delete"></i>
            </a>
            <a
              href="#"
              class="btn green darken-2 waves-effect waves-light compact2-btn"
              data-position="bottom"
              data-delay="50"
              data-tooltip="check"
              ><i class="zmdi zmdi-check"></i
            ></a>
          </td>
        </tr>
        <tr>
          <td>Sonya</td>
          <td>Frost</td>
          <td>***</td>
          <td class="sorting_1">
            <span class="new badge orange" data-badge-caption="">Falta</span>
          </td>
          <td>
            <select>
              <option value="" disabled selected>ninguno</option>
              <option value="1">Preceptor</option>
              <option value="2">Docente</option>
              <option value="3">Admin</option>
              <option value="3">nose</option>
            </select>
          </td>
          <td>
            <a class="btn red darken-2 waves-effect waves-light compact-btn">
              <i class="zmdi zmdi-delete"></i>
            </a>
            <a
              href="#"
              class="btn green darken-2 waves-effect waves-light compact2-btn"
              data-position="bottom"
              data-delay="50"
              data-tooltip="check"
              ><i class="zmdi zmdi-check"></i
            ></a>
          </td>
        </tr>
        <tr>
          <td>Jena</td>
          <td>Gaines</td>
          <td>***</td>
          <td class="sorting_1">
            <span class="new badge orange" data-badge-caption="">Falta</span>
          </td>
          <td>
            <select>
              <option value="" disabled selected>ninguno</option>
              <option value="1">Preceptor</option>
              <option value="2">Docente</option>
              <option value="3">Admin</option>
              <option value="3">nose</option>
            </select>
          </td>
          <td>
            <a class="btn red darken-2 waves-effect waves-light compact-btn">
              <i class="zmdi zmdi-delete"></i>
            </a>
            <a
              href="#"
              class="btn green darken-2 waves-effect waves-light compact2-btn"
              data-position="bottom"
              data-delay="50"
              data-tooltip="done"
              ><i class="zmdi zmdi-check"></i
            ></a>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</div>
<?php $this->load->view('menus/Footer');?>