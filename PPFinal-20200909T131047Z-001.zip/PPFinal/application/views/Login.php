<?php $this->load->view('menus/Head');?>
<body class="font-cover" id="login">
  <div
    class="container-login center-align"
    style="background-color: rgba(0,0,0,0.5);opacity: 1;"
  >
    <div style="margin:15px 0;">
      <i class="zmdi zmdi-account-circle zmdi-hc-5x" style="color: white;"></i>
      <p style="color: white;">Inicia sesión con tu cuenta</p>
    </div>
    <form action="<?= base_url('Login')?>">
      <div class="input-field">
        <input
          id="UserName"
          type="text"
          class="validate"
          style="color: white;"
          required="required"
        />
        <label for="UserName"
          ><i class="zmdi zmdi-account"></i>&nbsp; Nombre</label
        >
      </div>
      <div class="input-field">
        <input
          id="Password"
          type="password"
          class="validate"
          style="color: white;"
          required="required"
        />
        <label for="Password"
          ><i class="zmdi zmdi-lock"></i>&nbsp; Contraseña</label
        >
      </div>
      <br />
      <button class="waves-effect waves-teal btn-flat">
        Ingresar &nbsp; <i class="zmdi zmdi-mail-send"></i>
      </button>
    </form>
    <div class="divider" style="margin: 20px 0;"></div>
    <a href="<?= base_url('CrearCuenta')?>">Crear cuenta</a> /
    <a href="#">Olvide la Contraseña</a>
  </div>
  <?php $this->load->view('menus/Script');?>
