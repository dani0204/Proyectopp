jQuery(document).ready(function(){

    jQuery(".btn-success-message").click(function() {
        swal("Texto del mensaje");
    });
    
    jQuery(".msg-basico-txt").click(function() {
        swal("Texto del tÃ­tulo", "Texto del mensaje inferior");
    });
    
    jQuery(".btn-peligro").click(function() {
        swal({
            title: "¿Seguro que deseas Eliminar?",   
            text: "No podras deshacer este paso...",   
            type: "error",   
            showCancelButton: true,
            cancelButtonText: "DENEGAR",   
            confirmButtonColor: "#DD6B55",   
            confirmButtonText: "CONTINUAR",   
            closeOnConfirm: false }, 
    
            function(){   
                swal("¡Hecho!", 
                    "Acabas de borrar un Usuario.", 
                    "success"); 
        });
    
    });
    
    jQuery(".btn-exito").click(function() {
        swal({
            title: "¿Seguro que deseas darle permiso?",   
            text: "No podras deshacer este paso...",   
            type: "success",   
            showCancelButton: true,
            cancelButtonText: "DENEGAR",   
            confirmButtonColor: "#DD6B55",   
            confirmButtonText: "ACEPTAR",   
            closeOnConfirm: false }, 
    
            function(){   
                swal("¡Hecho!", 
                    "Acabas de dar permiso a un Usuario.", 
                    "success"); 
        });
    });
    
    
    
    jQuery(".msg-cond").click(function() {
        swal({   
            title: "Â¿Deseas unirte al lado oscuro?",   
            text: "Este paso marcarÃ¡ el resto de tu vida...",   
            type: "warning",   
            showCancelButton: true,   
            confirmButtonColor: "#DD6B55",   
            confirmButtonText: "Â¡Claro!",   
            cancelButtonText: "No, jamÃ¡s",   
            closeOnConfirm: false,   
            closeOnCancel: false }, 
    
            function(isConfirm){   
                if (isConfirm) {     
                    swal("Â¡Hecho!", 
                        "Ahora eres uno de los nuestros", 
                        "success");   
                } else {     
                    swal("Â¡Gallina!", 
                        "Tu te lo pierdes...", 
                    "error");   
                } 
            });
    });
    
    jQuery(".msg-autoclose").click(function() {
        swal({   
            title: "Gracias por registrarse",   
            timer: 1000,   
            showConfirmButton: false 
        });
    
    });
    jQuery(".msg-nose").click(function() {
        swal({   
            title: "Gracias por registrarse",   
            text: "Se cerrarÃ¡ en 3 segundos.",   
            timer: 3000,   
            showConfirmButton: false 
        });
    
    });
    jQuery(".btn-jeje").click(function() {
        swal({
            title: "¿Seguro que deseas Eliminar?",   
            text: "No podras deshacer este paso...",   
            type: "error",   
            showCancelButton: true,
            cancelButtonText: "DENEGAR",   
            confirmButtonColor: "#DD6B55",   
            confirmButtonText: "CONTINUAR",   
            closeOnConfirm: false }, 
    
            function(){   
                swal("¡Hecho!", 
                    "Acabas de borrar un Usuario.", 
                    "success"); 
        });
    
    });
    
    });